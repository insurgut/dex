import java.lang.ref.WeakReference;
import java.lang.reflect.*;
public class TestRetention2311 {
 static Object retainedState,retainedSnapshot;
 static WeakReference<Object>[] create()throws Exception{
  Object cell=new Object();java.util.ArrayList<Object> adapter=new java.util.ArrayList<Object>();adapter.add(cell);
  Class<?> state=Class.forName("ru.surgut.repeatfold.Core$State");Constructor<?> ctor=state.getDeclaredConstructor(Object.class,int.class,int.class);ctor.setAccessible(true);retainedState=ctor.newInstance(adapter,0,1);
  Class<?> snapshot=Class.forName("ru.surgut.repeatfold.Core$Snapshot");Constructor<?> sc=snapshot.getDeclaredConstructor();sc.setAccessible(true);retainedSnapshot=sc.newInstance();java.util.ArrayList<Object> list=new java.util.ArrayList<Object>();list.add(adapter);Field f=snapshot.getDeclaredField("list");f.setAccessible(true);f.set(retainedSnapshot,new WeakReference<Object>(list));
  return new WeakReference[]{new WeakReference<Object>(adapter),new WeakReference<Object>(cell),new WeakReference<Object>(list)};
 }
 public static void main(String[] args)throws Exception{
  WeakReference<Object>[] refs=create();for(int i=0;i<40&&(refs[0].get()!=null||refs[1].get()!=null||refs[2].get()!=null);i++){System.gc();Thread.sleep(10);}
  for(WeakReference<Object> r:refs)if(r.get()!=null)throw new AssertionError("cache retained UI/list");
  System.out.println("PASS real Core State/Snapshot: keeping cache values does not retain adapter, cell or message list");
 }
}
