import ru.surgut.repeatfold.Grouping;
import java.util.Arrays;
public class TestLongBlocks {
 static void check(int[] got,int...want){if(!Arrays.equals(got,want))throw new AssertionError(Arrays.toString(got)+" != "+Arrays.toString(want));}
 public static void main(String[] args){
  String[] e={"Привет","Ты как там?","Чем занимаешься?","Как себя чувствуешь?"},a={"x","x","x","x"};int[] d={4,3,2,1};
  int[] c=Grouping.counts(e,new String[4],d,true,3,3,2);check(c,1,1,1,1);check(Grouping.links(e,a,d,c,true,2),1,3,3,2);
  check(Grouping.links(e,a,new int[]{10,9,2,1},c,true,2),1,2,1,2);
  check(Grouping.links(e,new String[]{"x","y","x","x"},d,c,true,2),0,0,1,2);
  check(Grouping.links(e,a,d,c,false,2),0,0,0,0);
  check(Grouping.links(e,new String[]{"x",null,"x","x"},d,c,true,2),0,0,1,2);
  String[] repeated={"Привет","Привет","Другой текст"};int[] counts=Grouping.counts(repeated,new String[3],new int[]{3,2,1},true,3,3,2);check(counts,2,-1,1);check(Grouping.links(repeated,new String[]{"x","x","x"},new int[]{3,2,1},counts,true,2),0,0,0);
  if(Grouping.longText("ab")||Grouping.longText("  ab  ")||Grouping.longText("😀😀")||!Grouping.longText("abc")||!Grouping.longText("😀😀😀"))throw new AssertionError("Unicode length");
  int[] protectedCounts=Grouping.counts(new String[3],new String[3],new int[]{3,2,1},true,3,3,2);check(protectedCounts,1,1,1);check(Grouping.links(repeated,new String[]{"x","x","x"},new int[]{3,2,1},protectedCounts,true,3),1,3,2);
  if(Grouping.longText("Привет",10)||!Grouping.longText("Привет",3))throw new AssertionError("configurable minimum");
  // Newest row is at index 0 and visually at the bottom. Only it retains metadata.
  int[] joined=Grouping.links(e,a,d,c,true,3);for(int i=0;i<joined.length;i++)if(((joined[i]&2)==0)!=(i==0))throw new AssertionError("bottom-only metadata");
  int[] split=Grouping.links(e,a,new int[]{20,19,2,1},c,true,3);for(int i=0;i<split.length;i++)if(((split[i]&2)==0)!=(i==0||i==2))throw new AssertionError("metadata after split");
  String[] big=new String[10000],actors=new String[10000];int[] dates=new int[10000],ones=new int[10000];Arrays.fill(actors,"user");Arrays.fill(ones,1);for(int i=0;i<big.length;i++)big[i]="text"+i;
  for(int j=0;j<100;j++){int[] links=Grouping.links(big,actors,dates,ones,true,2);if(links[0]!=1||links[5000]!=3||links[9999]!=2)throw new AssertionError("stress");}
  System.out.println("PASS visible blocks, pauses, authors, toggle, short boundaries, duplicates, Unicode, 100x10000");
 }
}
