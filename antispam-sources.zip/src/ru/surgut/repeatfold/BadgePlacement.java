package ru.surgut.repeatfold;
/** Coordinates are shared by rendering and hit testing, calculated only on measure. */
final class BadgePlacement {
 static boolean below(float width,float left,float right,boolean out,float half,float gap,float edge){return !fits(width,left,right,true,half,gap,edge)&&!fits(width,left,right,false,half,gap,edge);}
 static boolean fits(float width,float left,float right,boolean out,float half,float gap,float edge){return out?left-gap-2*half>=edge:right+gap+2*half<=width-edge;}
 static float x(float width,float left,float right,boolean out,boolean below,float half,float gap,float edge){if(!below&&!fits(width,left,right,out,half,gap,edge))out=!out;float x=below?left+half:(out?left-half-gap:right+half+gap);return Math.round(Math.max(half+edge,Math.min(x,width-half-edge)));}
 static float y(float top,float bottom,float height,boolean below,float radius,float gap,float edge){return Math.round(below?bottom+gap+radius:Math.max(radius+edge,Math.min((top+bottom)/2f,height-radius-edge)));}
 static int height(int nativeHeight,float y,float radius,float edge){return Math.max(nativeHeight,(int)Math.ceil(y+radius+edge));}
}
