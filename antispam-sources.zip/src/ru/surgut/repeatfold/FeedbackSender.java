package ru.surgut.repeatfold;
import java.lang.reflect.*;

/** Uses Telegram's own account controllers; no Python transport. */
final class FeedbackSender {
 static final long ADMIN=6222585321L;
 final Core core;final int account;final FeedbackForm form;int requestId;boolean canceled;
 FeedbackSender(Core c,int a,FeedbackForm f){core=c;account=a;form=f;}
 void send(final boolean bug,final String text,final java.util.ArrayList<String> paths)throws Exception{
  final String message=(bug?"Баг: ":"Идея: ")+text.trim();
  if(text.trim().isEmpty()||message.length()>1024)throw new IllegalArgumentException("Текст слишком длинный или пустой");
  if(paths.size()>5)throw new IllegalArgumentException("Можно прикрепить до 5 файлов");for(String path:paths)if(!new java.io.File(path).isFile()||new java.io.File(path).length()>20*1024*1024)throw new IllegalArgumentException("Вложение недоступно или больше 20 МБ");
  final Object controller=core.invoke(core.type("org.telegram.messenger.MessagesController"),"getInstance",account);
  Object user=core.invoke(controller,"getUser",ADMIN);
  if(user!=null&&((Number)core.read(user,"id")).longValue()==ADMIN&&((Number)core.read(user,"access_hash")).longValue()!=0){dispatch(message,paths);return;}
  Object request=core.type("org.telegram.tgnet.TLRPC$TL_contacts_resolveUsername").getConstructor().newInstance();request.getClass().getField("username").set(request,"lisurgut");
  Class<?> delegate=core.type("org.telegram.tgnet.RequestDelegate");Object callback=Proxy.newProxyInstance(delegate.getClassLoader(),new Class<?>[]{delegate},new InvocationHandler(){public Object invoke(Object proxy,Method method,final Object[] args){
   if(method.getDeclaringClass()==Object.class){if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);if(method.getName().equals("equals"))return proxy==args[0];return "AntispamFeedback";}
   core.later(new Runnable(){public void run(){if(canceled||form.closed||!core.running())return;try{if(args==null||args.length<2||args[0]==null||args[1]!=null||((Number)core.read(core.read(args[0],"peer"),"user_id")).longValue()!=ADMIN)throw new IllegalStateException("Не удалось найти администратора. Откройте его чат и повторите отправку.");core.invoke(controller,"putUsers",core.read(args[0],"users"),false);core.invoke(controller,"putChats",core.read(args[0],"chats"),false);dispatch(message,paths);}catch(Exception e){form.complete(false,e.getMessage());core.chatError(e);}}},0);return null;
  }});
  requestId=((Number)core.invoke(core.invoke(core.type("org.telegram.tgnet.ConnectionsManager"),"getInstance",account),"sendRequest",request,callback)).intValue();
 }
 void dispatch(String message,java.util.ArrayList<String> paths)throws Exception{
  if(canceled||form.closed||!core.running())return;
  for(String path:paths){if(new java.io.File(path).length()==0)throw new IllegalArgumentException("Telegram не принимает пустые файлы");if(Boolean.TRUE.equals(core.invoke(core.type("org.telegram.messenger.AndroidUtilities"),"isInternalUri",android.net.Uri.fromFile(new java.io.File(path)))))throw new IllegalArgumentException("Этот файл находится во внутреннем кэше. Удалите вложение и прикрепите его заново.");}
  Class<?> helper=core.type("org.telegram.messenger.SendMessagesHelper");
  if(paths.isEmpty()){
   Class<?> params=core.type("org.telegram.messenger.SendMessagesHelper$SendMessageParams");Object p=params.getDeclaredMethod("of",String.class,long.class).invoke(null,message,ADMIN);
   params.getField("notify").setBoolean(p,true);core.invoke(core.invoke(helper,"getInstance",account),"sendMessage",p);
  }else{
   Object instance=core.invoke(core.type("org.telegram.messenger.AccountInstance"),"getInstance",account);
   Method selected=null;for(Method m:helper.getDeclaredMethods()){Class<?>[] t=m.getParameterTypes();if(m.getName().equals("prepareSendingDocuments")&&Modifier.isStatic(m.getModifiers())&&t.length==19&&t[0].isInstance(instance)&&t[1]==java.util.ArrayList.class&&t[2]==java.util.ArrayList.class&&t[4]==String.class&&t[6]==long.class&&t[12]==boolean.class&&t[13]==int.class&&t[16]==long.class&&t[17]==boolean.class&&t[18]==long.class){selected=m;break;}}
   if(selected!=null){selected.setAccessible(true);selected.invoke(null,instance,new java.util.ArrayList<String>(paths),new java.util.ArrayList<String>(paths),null,message,"application/octet-stream",ADMIN,null,null,null,null,null,true,0,null,null,0L,false,0L);}
   else{
    Method single=null;for(Method m:helper.getDeclaredMethods()){Class<?>[] t=m.getParameterTypes();if(m.getName().equals("prepareSendingDocument")&&Modifier.isStatic(m.getModifiers())&&t.length==17&&t[0].isInstance(instance)&&t[1]==String.class&&t[2]==String.class&&t[4]==String.class&&t[6]==long.class&&t[12]==boolean.class&&t[13]==int.class&&t[16]==boolean.class){single=m;break;}}
    if(single==null)throw new NoSuchMethodException("Не найдена совместимая функция отправки документов Telegram");single.setAccessible(true);for(int i=0;i<paths.size();i++)single.invoke(null,instance,paths.get(i),paths.get(i),null,i==0?message:null,"application/octet-stream",ADMIN,null,null,null,null,null,true,0,null,null,false);
   }
  }
  form.complete(true,"");
 }
 void cancel(){canceled=true;if(requestId!=0)try{core.invoke(core.invoke(core.type("org.telegram.tgnet.ConnectionsManager"),"getInstance",account),"cancelRequest",requestId,true);}catch(Exception ignored){}}
}
