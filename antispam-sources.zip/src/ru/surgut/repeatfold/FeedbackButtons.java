package ru.surgut.repeatfold;
import android.content.*;
import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
final class FeedbackButtons{
 final Core core;final Context context;final int account,accent,bg;final float density;
 FeedbackButtons(Core c,Context x,int a,int color,int background){core=c;context=x;account=a;accent=color;bg=background;density=x.getResources().getDisplayMetrics().density;}
 int dp(int v){return (int)(v*density+.5f);}
 View create()throws Exception{LinearLayout root=new LinearLayout(context);root.setPadding(dp(12),dp(12),dp(12),dp(16));for(int i=0;i<2;i++){final boolean bug=i==1;LinearLayout button=new LinearLayout(context);button.setGravity(Gravity.CENTER);button.setPadding(dp(6),dp(8),dp(6),dp(8));GradientDrawable shape=new GradientDrawable();shape.setColor(bg);float large=dp(22),small=dp(5);shape.setCornerRadii(bug?new float[]{small,small,large,large,large,large,small,small}:new float[]{large,large,small,small,small,small,large,large});button.setBackgroundDrawable(shape);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(60),1);if(bug)lp.leftMargin=dp(3);root.addView(button,lp);
 final Drawable emoji=(Drawable)core.type("org.telegram.ui.Components.AnimatedEmojiDrawable").getDeclaredMethod("make",int.class,int.class,long.class).invoke(null,account,0,bug?5994378304751145264L:5994473545650934240L);emoji.setColorFilter(new PorterDuffColorFilter(accent,PorterDuff.Mode.SRC_IN));View icon=new View(context){protected void onDraw(Canvas c){emoji.setBounds(0,0,getWidth(),getHeight());emoji.draw(c);}};icon.setWillNotDraw(false);button.addView(icon,new LinearLayout.LayoutParams(dp(24),dp(24)));icon.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){try{core.attachSettingsEmoji(emoji,v);}catch(Exception e){core.chatError(e);}}public void onViewDetachedFromWindow(View v){try{core.detachSettingsEmoji(emoji,v);}catch(Exception e){core.chatError(e);}}});TextView label=new TextView(context);label.setText(bug?"Сообщить о баге":"Подать идею");label.setTextSize(13);label.setTextColor(accent);label.setPadding(dp(6),0,0,0);button.addView(label,new LinearLayout.LayoutParams(-2,-2));button.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{Context ctx=context;while(ctx instanceof ContextWrapper&&!(ctx instanceof Activity)){Context next=((ContextWrapper)ctx).getBaseContext();if(next==ctx)break;ctx=next;}if(!(ctx instanceof Activity))throw new IllegalStateException("Нет активного окна");core.showFeedback((Activity)ctx,account,bug);}catch(Exception e){core.chatError(e);}}});}return root;}
}
