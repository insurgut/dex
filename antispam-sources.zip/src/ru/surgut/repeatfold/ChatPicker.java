package ru.surgut.repeatfold;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Only visible rows allocate avatars; all callbacks remain inside DEX. */
final class ChatPicker {
 final Core core;final Activity activity;final int account;final ArrayList<Entry> entries=new ArrayList<>();
 final int textColor,secondary,bg;final float density;
 final ArrayList<Entry> visible=new ArrayList<>(); final TextView[] chips=new TextView[3]; int filter=-1; Rows rows; ListView list;
 static final class Entry {long id;Object peer;String name,username;boolean pinned,group;int pin,date;}
 ChatPicker(Core c,Activity a)throws Exception{
  core=c;activity=a;density=a.getResources().getDisplayMetrics().density;
  account=((Number)c.read(c.type("org.telegram.messenger.UserConfig"),"selectedAccount")).intValue();
  Class<?> theme=c.type("org.telegram.ui.ActionBar.Theme");
  textColor=color(theme,"key_windowBackgroundWhiteBlackText");secondary=color(theme,"key_windowBackgroundWhiteGrayText");bg=color(theme,"key_dialogBackground");
  Object controller=c.invoke(c.type("org.telegram.messenger.MessagesController"),"getInstance",account);
  List<?> dialogs=(List<?>)c.invoke(controller,"getAllDialogs");HashSet<Long> seen=new HashSet<>();
  for(Object d:new ArrayList<Object>(dialogs)){
   long id=((Number)c.read(d,"id")).longValue();if(id==0||!seen.add(id))continue;
   Object peer=id>0?c.invoke(controller,"getUser",Long.valueOf(id)):c.invoke(controller,"getChat",Long.valueOf(-id));
   if(peer==null)continue;
   Entry e=new Entry();e.id=id;e.peer=peer;e.group=id<0&&(!"true".equals(value(peer,"broadcast"))||"true".equals(value(peer,"megagroup")));
   if(id>0)e.name=(value(peer,"first_name")+" "+value(peer,"last_name")).trim();else e.name=value(peer,"title");
   if(e.name.isEmpty())e.name="Удаленный аккаунт";
   e.username=value(peer,"username");
   if(e.username.isEmpty())try{for(Object u:(List<?>)c.read(peer,"usernames"))if(Boolean.TRUE.equals(c.read(u,"active"))){e.username=value(u,"username");break;}}catch(Exception ignored){}
   e.pinned=Boolean.TRUE.equals(c.read(d,"pinned"));e.pin=((Number)c.read(d,"pinnedNum")).intValue();e.date=((Number)c.read(d,"last_message_date")).intValue();entries.add(e);
  }
  Collections.sort(entries,new Comparator<Entry>(){public int compare(Entry a,Entry b){if(a.pinned!=b.pinned)return a.pinned?-1:1;return Integer.compare(a.pinned?b.pin:b.date,a.pinned?a.pin:a.date);}});
  visible.addAll(entries);
 }
 String value(Object o,String key){try{Object v=core.read(o,key);return v==null?"":v.toString();}catch(Exception e){return "";}}
 int color(Class<?> theme,String key)throws Exception{return ((Number)core.invoke(theme,"getColor",((Number)core.read(theme,key)).intValue())).intValue();}
 int dp(int n){return (int)(n*density+.5f);}
 TextView text(String s,int size,int color){TextView t=new TextView(activity);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
 Dialog show()throws Exception{
  final int sheetHeight=Math.min(dp(600),activity.getResources().getDisplayMetrics().heightPixels*3/4);
  LinearLayout root=new LinearLayout(activity){
   @Override protected void onMeasure(int widthSpec,int heightSpec){
    int limit=View.MeasureSpec.getMode(heightSpec)==View.MeasureSpec.UNSPECIFIED?sheetHeight:Math.min(sheetHeight,View.MeasureSpec.getSize(heightSpec));
    super.onMeasure(widthSpec,View.MeasureSpec.makeMeasureSpec(limit,View.MeasureSpec.EXACTLY));
   }
  };root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(12),dp(12),dp(12));
  LinearLayout filters=new LinearLayout(activity);filters.setGravity(Gravity.CENTER_VERTICAL);
  String[] labels={"Группы","Закрепленные","Личные чаты"};
  for(int i=0;i<3;i++){
   final int index=i;TextView chip=text(labels[i],14,textColor);chips[i]=chip;chip.setGravity(Gravity.CENTER);chip.setSingleLine(true);
   LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(44),1);if(i>0)lp.leftMargin=dp(3);filters.addView(chip,lp);
   chip.setOnClickListener(new View.OnClickListener(){public void onClick(View v){filter=filter==index?-1:index;applyFilter();}});
  }
  root.addView(filters);LinearLayout.LayoutParams filterParams=(LinearLayout.LayoutParams)filters.getLayoutParams();filterParams.bottomMargin=dp(10);
  list=new ListView(activity){
   @Override public boolean dispatchTouchEvent(MotionEvent event){
    if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
    boolean handled=super.dispatchTouchEvent(event);
    if((event.getActionMasked()==MotionEvent.ACTION_UP||event.getActionMasked()==MotionEvent.ACTION_CANCEL)&&getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
    return handled;
   }
  };list.setDivider(new ColorDrawable(Color.TRANSPARENT));list.setDividerHeight(dp(3));list.setVerticalScrollBarEnabled(false);rows=new Rows();list.setAdapter(rows);applyFilter();
  root.addView(list,new LinearLayout.LayoutParams(-1,0,1));

  Object builder=core.type("org.telegram.ui.ActionBar.BottomSheet$Builder").getConstructor(android.content.Context.class).newInstance(activity);
  core.invoke(builder,"setCustomView",root);
  final Dialog sheet=(Dialog)core.invoke(builder,"create");
  core.invoke(sheet,"setCanDismissWithSwipe",false);
  final Bitmap backdrop=makeBlur();
  core.invoke(sheet,"setBackgroundColor",Color.TRANSPARENT);
  sheet.show();
  if(backdrop!=null){View container=(View)core.read(sheet,"container");BitmapDrawable blur=new BitmapDrawable(activity.getResources(),backdrop);blur.setGravity(Gravity.FILL);container.setBackgroundDrawable(blur);}
  sheet.setOnDismissListener(new android.content.DialogInterface.OnDismissListener(){public void onDismiss(android.content.DialogInterface d){core.chatClosed(sheet);try{((View)core.read(sheet,"container")).setBackgroundDrawable(null);}catch(Exception ignored){}if(backdrop!=null&&!backdrop.isRecycled())backdrop.recycle();if(list!=null)list.setAdapter(null);entries.clear();visible.clear();sheet.setOnDismissListener(null);}});
  return sheet;
 }
 GradientDrawable block(int position,int count,boolean selected){
  float big=dp(20),small=dp(5);float tl=position==0?big:small,tr=tl,bl=position==count-1?big:small,br=bl;
  GradientDrawable d=new GradientDrawable();d.setColor((bg&0x00ffffff)|((selected?220:125)<<24));
  d.setCornerRadii(new float[]{tl,tl,tr,tr,br,br,bl,bl});return d;
 }
 void applyFilter(){
  visible.clear();for(Entry e:entries)if(filter<0||filter==0&&e.group||filter==1&&e.pinned||filter==2&&e.id>0)visible.add(e);
  for(int i=0;i<3;i++){
   float big=dp(22),small=dp(5),l=i==0?big:small,r=i==2?big:small;
   if(filter==i)l=r=big;
   GradientDrawable d=new GradientDrawable();d.setColor((bg&0x00ffffff)|((filter==i?230:135)<<24));d.setCornerRadii(new float[]{l,l,r,r,r,r,l,l});chips[i].setBackgroundDrawable(d);chips[i].setAlpha(filter<0||filter==i?1f:.7f);chips[i].setSelected(filter==i);
  }
  if(rows!=null)rows.notifyDataSetChanged();if(list!=null)list.setSelection(0);
 }
 Bitmap makeBlur(){
  try{
   View source=activity.getWindow().getDecorView();int w=Math.max(1,source.getWidth()/8),h=Math.max(1,source.getHeight()/8);
   Bitmap image=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);canvas.scale(w/(float)source.getWidth(),h/(float)source.getHeight());source.draw(canvas);
   int[] pixels=new int[w*h],temp=new int[w*h];image.getPixels(pixels,0,w,0,0,w,h);
   for(int pass=0;pass<2;pass++){blurPass(pixels,temp,w,h,3,true);blurPass(temp,pixels,w,h,3,false);}
   image.setPixels(pixels,0,w,0,0,w,h);return image;
  }catch(Throwable ex){core.chatError(ex);return null;}
 }
 static void blurPass(int[] input,int[] output,int w,int h,int radius,boolean horizontal){
  int lines=horizontal?h:w,len=horizontal?w:h;
  for(int line=0;line<lines;line++){
   int red=0,green=0,blue=0,count=radius*2+1;
   for(int k=-radius;k<=radius;k++){int p=Math.max(0,Math.min(len-1,k));int color=input[horizontal?line*w+p:p*w+line];red+=(color>>16)&255;green+=(color>>8)&255;blue+=color&255;}
   for(int p=0;p<len;p++){
    output[horizontal?line*w+p:p*w+line]=0xff000000|((red/count)<<16)|((green/count)<<8)|(blue/count);
    int left=Math.max(0,p-radius),right=Math.min(len-1,p+radius+1);int a=input[horizontal?line*w+left:left*w+line],b=input[horizontal?line*w+right:right*w+line];
    red+=((b>>16)&255)-((a>>16)&255);green+=((b>>8)&255)-((a>>8)&255);blue+=(b&255)-(a&255);
   }
  }
 }
 final class Holder {CheckBox check;TextView name,user;View avatar;Object drawable;}
 final class Rows extends BaseAdapter {
  public int getCount(){return visible.size();}public Object getItem(int p){return visible.get(p);}public long getItemId(int p){return visible.get(p).id;}
  public View getView(int position,View recycled,ViewGroup parent){
   final Entry e=visible.get(position);Holder h;LinearLayout row;
   try{
    if(!(recycled instanceof LinearLayout)){
     row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(16),dp(8));h=new Holder();
     h.check=new CheckBox(activity);h.check.setClickable(false);h.check.setFocusable(false);row.addView(h.check,new LinearLayout.LayoutParams(dp(40),dp(48)));
     h.avatar=(View)core.type("org.telegram.ui.Components.BackupImageView").getConstructor(android.content.Context.class).newInstance(activity);
     core.invoke(h.avatar,"setRoundRadius",dp(24));h.drawable=core.type("org.telegram.ui.Components.AvatarDrawable").getConstructor().newInstance();
     row.addView(h.avatar,new LinearLayout.LayoutParams(dp(48),dp(48)));
     LinearLayout labels=new LinearLayout(activity);labels.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(12);row.addView(labels,lp);
     h.name=text("",16,textColor);h.name.setSingleLine(true);h.name.setEllipsize(TextUtils.TruncateAt.END);labels.addView(h.name);
     h.user=text("",14,secondary);h.user.setSingleLine(true);h.user.setEllipsize(TextUtils.TruncateAt.END);labels.addView(h.user);row.setTag(h);
    }else{row=(LinearLayout)recycled;h=(Holder)row.getTag();}
    row.setBackgroundDrawable(block(position,visible.size(),false));
    h.name.setText(e.name);h.user.setText(e.username.isEmpty()?"":"@"+e.username);h.user.setVisibility(e.username.isEmpty()?View.GONE:View.VISIBLE);h.check.setChecked(core.chatEnabled(account,e.id));
    core.invoke(h.drawable,"setInfo",account,e.peer);core.invoke(h.avatar,"setForUserOrChat",e.peer,h.drawable);
    final Holder holder=h;row.setContentDescription(e.name+", "+(core.chatEnabled(account,e.id)?"антиспам включен":"антиспам выключен"));
    row.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{boolean enabled=!core.chatEnabled(account,e.id);core.setChatEnabled(account,e.id,enabled);holder.check.setChecked(enabled);v.setContentDescription(e.name+", "+(enabled?"антиспам включен":"антиспам выключен"));}catch(Exception ex){core.chatError(ex);}}});return row;
   }catch(Exception ex){core.chatError(ex);return text(e.name+" - не удалось показать строку",16,textColor);}
  }
 }
}
