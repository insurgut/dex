package ru.surgut.repeatfold;
import java.util.Arrays;
/** Pure native grouping algorithm; also exercised on the JVM during builds. */
public final class Grouping {
 private Grouping(){}
 public static int[] counts(String[] exact,String[] actor,int[] dates,boolean rapid,int threshold,int window,int pause){
  int n=exact.length;int[] counts=new int[n];Arrays.fill(counts,1);
  for(int start=0;start<n;){int end=start+1;if(exact[start]!=null)while(end<n&&exact[start].equals(exact[end]))end++;fold(counts,start,end);start=end;}
  if(rapid)for(int start=0;start<n;){if(actor[start]==null){start++;continue;}int end=start+1;while(end<n&&actor[start].equals(actor[end])&&Math.abs(dates[end-1]-dates[end])<=pause)end++;boolean qualifies=false;for(int i=start;i+threshold<=end;i++)if(Math.abs(dates[i]-dates[i+threshold-1])<=window){qualifies=true;break;}if(qualifies)fold(counts,start,end);start=end;}
  return counts;
 }
 /** At least three Unicode code points, excluding surrounding whitespace. */
 public static boolean longText(String text){return longText(text,3);}
 public static boolean longText(String text,int min){if(text==null)return false;String t=text.trim();return t.codePointCount(0,t.length())>=min;}
 /** Reverse chronological order: bit 1 connects to the older/top bubble, bit 2 to newer/bottom. */
 public static int[] links(String[] exact,String[] actor,int[] dates,int[] counts,boolean enabled,int pause){
  int[] links=new int[actor.length];if(!enabled)return links;
  for(int i=0;i+1<actor.length;i++)if(counts[i]==1&&counts[i+1]==1&&actor[i]!=null&&actor[i].equals(actor[i+1])&&exact[i]!=null&&exact[i+1]!=null&&Math.abs((long)dates[i]-dates[i+1])<=pause){links[i]|=1;links[i+1]|=2;}
  return links;
 }
 private static void fold(int[] counts,int start,int end){if(end-start<2)return;counts[start]=end-start;for(int i=start+1;i<end;i++)counts[i]=-1;}
}
