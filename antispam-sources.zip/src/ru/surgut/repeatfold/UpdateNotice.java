package ru.surgut.repeatfold;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

/** Lightweight native update bulletin; no Python drawing callbacks. */
final class UpdateNotice {
 final Core core;final Activity activity;Runnable action;final float density;final boolean preview;
 android.app.Dialog dialog;android.graphics.Bitmap backdrop;TextView changes;volatile boolean closed;volatile java.net.HttpURLConnection activeConnection;
 LinearLayout bar;ViewGroup parent;Drawable emoji;View icon;
 UpdateNotice(Core c,Activity a,Runnable r){this(c,a,r,false);}
 UpdateNotice(Core c,Activity a,Runnable r,boolean test){core=c;activity=a;action=r;preview=test;density=a.getResources().getDisplayMetrics().density;}
 int dp(int v){return (int)(v*density+.5f);}
 int color(String key)throws Exception{Class<?> t=core.type("org.telegram.ui.ActionBar.Theme");return ((Number)core.invoke(t,"getColor",((Number)core.read(t,key)).intValue())).intValue();}
 void show()throws Exception{
  View source=activity.getWindow().getDecorView();backdrop=capture(source);final FrameLayout overlay=new FrameLayout(activity);parent=overlay;if(backdrop!=null){android.graphics.drawable.BitmapDrawable blur=new android.graphics.drawable.BitmapDrawable(activity.getResources(),backdrop);blur.setGravity(Gravity.FILL);overlay.setBackgroundDrawable(blur);}overlay.setOnClickListener(new View.OnClickListener(){public void onClick(View v){dismiss();}});bar=new LinearLayout(activity);bar.setOrientation(LinearLayout.VERTICAL);bar.setClickable(true);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),dp(16),dp(18),dp(16));
  GradientDrawable bg=new GradientDrawable();bg.setColor(color("key_windowBackgroundWhite"));bg.setCornerRadius(dp(32));bar.setBackgroundDrawable(bg);
  try{core.invoke(bar,"setElevation",(float)dp(8));}catch(Exception ignored){}
  LinearLayout heading=new LinearLayout(activity);heading.setGravity(Gravity.CENTER_VERTICAL);bar.addView(heading,new LinearLayout.LayoutParams(-1,-2));
  icon=new View(activity){protected void onDraw(Canvas c){if(emoji!=null){int saved=c.save();try{emoji.setBounds(dp(2),dp(2),getWidth()-dp(2),getHeight()-dp(2));emoji.draw(c);}finally{c.restoreToCount(saved);}}}};
  icon.setWillNotDraw(false);
  heading.addView(icon,new LinearLayout.LayoutParams(dp(36),dp(36)));
  TextView label=new TextView(activity);label.setText(preview?"Проверка уведомления":"Доступно обновление ядра");label.setTextSize(14);label.setTextColor(color("key_windowBackgroundWhiteBlackText"));label.setPadding(dp(8),0,dp(8),0);heading.addView(label,new LinearLayout.LayoutParams(0,-2,1));
  TextView button=new TextView(activity);button.setText(preview?"Закрыть":"Обновить");button.setTextSize(14);button.setGravity(Gravity.CENTER);button.setTextColor(color("key_windowBackgroundWhiteBlueText"));button.setPadding(dp(10),0,dp(10),0);heading.addView(button,new LinearLayout.LayoutParams(-2,dp(44)));
  button.setOnClickListener(new View.OnClickListener(){public void onClick(View v){Runnable selected=action;dismiss();if(core.running()&&selected!=null)selected.run();}});
  changes=new TextView(activity);changes.setText("Загрузка списка изменений...");changes.setTextSize(14);changes.setTextColor(color("key_windowBackgroundWhiteBlackText"));changes.setPadding(0,dp(12),0,dp(8));
  ScrollView scroll=new ScrollView(activity);scroll.addView(changes,new ScrollView.LayoutParams(-1,-2));bar.addView(scroll,new LinearLayout.LayoutParams(-1,dp(164)));
  FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);lp.setMargins(dp(12),0,dp(12),dp(8));overlay.addView(bar,lp);
  dialog=new android.app.Dialog(activity);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);dialog.setContentView(overlay);dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener(){public void onDismiss(android.content.DialogInterface d){cleanup();}});dialog.show();dialog.getWindow().setLayout(-1,-1);fetchChanges();
  try{int account=((Number)core.read(core.type("org.telegram.messenger.UserConfig"),"selectedAccount")).intValue();loadEmoji(account);}catch(Throwable ex){core.chatError(ex);}

 }
 void loadEmoji(int account)throws Exception{Class<?> t=core.type("org.telegram.ui.Components.AnimatedEmojiDrawable");emoji=(Drawable)t.getDeclaredMethod("make",int.class,int.class,long.class).invoke(null,account,0,5877410604225924969L);emoji.setColorFilter(new android.graphics.PorterDuffColorFilter(color("key_windowBackgroundWhiteBlueText"),android.graphics.PorterDuff.Mode.SRC_IN));t.getDeclaredMethod("addView",View.class).invoke(emoji,icon);icon.invalidate();}
 android.graphics.Bitmap capture(View source){try{int w=Math.max(1,source.getWidth()/8),h=Math.max(1,source.getHeight()/8);android.graphics.Bitmap b=android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.scale(w/(float)Math.max(1,source.getWidth()),h/(float)Math.max(1,source.getHeight()));source.draw(c);int[] p=new int[w*h],t=new int[w*h];b.getPixels(p,0,w,0,0,w,h);for(int i=0;i<2;i++){ChatPicker.blurPass(p,t,w,h,3,true);ChatPicker.blurPass(t,p,w,h,3,false);}b.setPixels(p,0,w,0,0,w,h);return b;}catch(Throwable e){core.chatError(e);return null;}}
 void fetchChanges(){new Thread(new Runnable(){public void run(){String result;java.net.HttpURLConnection connection=null;try{connection=(java.net.HttpURLConnection)new java.net.URL("https://raw.githubusercontent.com/insurgut/dex/main/CHANGELOG.md?t="+System.currentTimeMillis()).openConnection();activeConnection=connection;if(closed)return;connection.setConnectTimeout(10000);connection.setReadTimeout(10000);java.io.InputStream in=connection.getInputStream();java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();try{byte[] buffer=new byte[2048];int n;while((n=in.read(buffer))!=-1){if(bytes.size()+n>32768)throw new java.io.IOException("Changelog too large");bytes.write(buffer,0,n);}}finally{in.close();}result=new String(bytes.toByteArray(),"UTF-8");}catch(Exception e){result="Не удалось загрузить список изменений";}finally{if(connection!=null)try{connection.disconnect();}catch(Throwable ignored){}activeConnection=null;}if(closed||!core.running())return;final String text=result;core.later(new Runnable(){public void run(){if(closed||!core.running())return;try{android.text.SpannableString styled=new android.text.SpannableString(text);java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?m)^(Доб\\.:|Изм\\.:|Фикс:|Уд\\.:)").matcher(text);int accent=color("key_windowBackgroundWhiteBlueText");while(m.find())styled.setSpan(new android.text.style.ForegroundColorSpan(accent),m.start(),m.end(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);changes.setText(styled);}catch(Exception e){core.chatError(e);}}},0);}},"AntispamChangelog").start();}
 void dismiss(){if(dialog!=null){dialog.dismiss();dialog=null;}else cleanup();}
 void cleanup(){if(closed)return;closed=true;core.noticeClosed(this);action=null;java.net.HttpURLConnection connection=activeConnection;activeConnection=null;if(connection!=null)try{connection.disconnect();}catch(Throwable ignored){}if(emoji!=null)try{core.invoke(emoji,"removeView",icon);}catch(Exception ignored){}emoji=null;bar=null;if(parent!=null)parent.setBackgroundDrawable(null);if(backdrop!=null){backdrop.recycle();backdrop=null;}if(parent!=null)parent.removeAllViews();parent=null;icon=null;changes=null;dialog=null;}
}
