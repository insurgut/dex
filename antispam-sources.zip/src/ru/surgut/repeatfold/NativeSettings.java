package ru.surgut.repeatfold;
import android.app.*;
import android.content.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

/** Feature controls live in DEX and can evolve without changing the bootstrap. */
final class NativeSettings {
 final Core core;final Context context;final Object provider;final int account;final SharedPreferences prefs;final float density;
 final java.util.ArrayList<View> rows=new java.util.ArrayList<View>();
 final LinearLayout parameters;final LinearLayout blockParameters;final int color,bg;final int[] thresholds={3,5,7,10},windows={2,3,5,10},pauses={1,2,3,5};
 NativeSettings(Core c,Context ctx,int a,Object p)throws Exception{
  core=c;context=ctx;account=a;provider=p;density=ctx.getResources().getDisplayMetrics().density;
  prefs=ctx.getApplicationContext().getSharedPreferences("antispam_native_settings",0);
  Class<?> theme=c.type("org.telegram.ui.ActionBar.Theme");
  color=((Number)c.invoke(theme,"getColor",((Number)c.read(theme,"key_windowBackgroundWhiteBlackText")).intValue(),p)).intValue();
  bg=((Number)c.invoke(theme,"getColor",((Number)c.read(theme,"key_windowBackgroundWhite")).intValue(),p)).intValue();
  parameters=new LinearLayout(ctx);parameters.setOrientation(LinearLayout.VERTICAL);blockParameters=new LinearLayout(ctx);blockParameters.setOrientation(LinearLayout.VERTICAL);
 }
 int dp(int n){return (int)(n*density+.5f);}
 GradientDrawable background(){GradientDrawable d=new GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(12));return d;}
 View cell(String title,String value)throws Exception{
  Class<?> providerType=core.type("org.telegram.ui.ActionBar.Theme$ResourcesProvider");
  View row=(View)core.type("org.telegram.ui.Cells.TextSettingsCell").getConstructor(Context.class,providerType).newInstance(context,provider);
  if(value==null)core.invoke(row,"setText",title,false);else core.invoke(row,"setTextAndValue",title,value,false);
  return row;
 }
 void add(LinearLayout root,View row){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(3);row.setBackgroundDrawable(background());root.addView(row,lp);rows.add(row);}
 void style(){java.util.ArrayList<View> visible=new java.util.ArrayList<View>();for(View row:rows){boolean shown=true;android.view.ViewParent parent=row.getParent();while(parent instanceof View){if(((View)parent).getVisibility()==View.GONE){shown=false;break;}parent=parent.getParent();}if(shown)visible.add(row);}for(int i=0;i<visible.size();i++){View row=visible.get(i);float t=dp(i==0?20:5),b=dp(i==visible.size()-1?20:5);GradientDrawable d=background();d.setCornerRadii(new float[]{t,t,t,t,b,b,b,b});row.setBackgroundDrawable(d);try{core.invoke(row,"setClipToOutline",true);}catch(Exception ignored){}}}
 void apply(){core.configure(prefs.getBoolean("rapid",true),prefs.getInt("threshold",5),prefs.getInt("window",3),prefs.getInt("pause",2));}
 Activity activity(){Context ctx=context;while(ctx instanceof ContextWrapper){if(ctx instanceof Activity)return (Activity)ctx;Context next=((ContextWrapper)ctx).getBaseContext();if(next==ctx)break;ctx=next;}return ctx instanceof Activity?(Activity)ctx:null;}
 View create()throws Exception{
  LinearLayout root=new LinearLayout(context);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutParams(new ViewGroup.LayoutParams(-1,-2));root.setClipChildren(false);root.setClipToPadding(false);
  root.addView(core.settingsHeader(context,account,provider),new LinearLayout.LayoutParams(-1,-2));
  LinearLayout controls=new LinearLayout(context);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(dp(12),0,dp(12),dp(12));root.addView(controls,new LinearLayout.LayoutParams(-1,-2));
  View chats=cell("Чаты с антиспамом",null);add(controls,chats);chats.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{Activity a=activity();if(a==null)throw new IllegalStateException("Нет окна для выбора чатов");core.showChats(a);}catch(Exception ex){core.chatError(ex);}}});
  final View toggle=(View)core.type("org.telegram.ui.Cells.TextCheckCell").getConstructor(Context.class,core.type("org.telegram.ui.ActionBar.Theme$ResourcesProvider")).newInstance(context,provider);
  core.invoke(toggle,"setTextAndCheck","Скрывать быстрый спам",prefs.getBoolean("rapid",true),false);add(controls,toggle);
  controls.addView(parameters,new LinearLayout.LayoutParams(-1,-2));
  parameter("Количество сообщений","threshold",thresholds,5,false);parameter("За сколько секунд","window",windows,3,true);parameter("Пауза завершения серии","pause",pauses,2,true);
  parameters.setVisibility(prefs.getBoolean("rapid",true)?View.VISIBLE:View.GONE);
  toggle.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{
   boolean enabled=!prefs.getBoolean("rapid",true);prefs.edit().putBoolean("rapid",enabled).apply();core.invoke(toggle,"setChecked",enabled);
   parameters.setVisibility(enabled?View.VISIBLE:View.GONE);parameters.requestLayout();style();apply();
  }catch(Exception ex){core.chatError(ex);}}});

  final View blockToggle=(View)core.type("org.telegram.ui.Cells.TextCheckCell").getConstructor(Context.class,core.type("org.telegram.ui.ActionBar.Theme$ResourcesProvider")).newInstance(context,provider);
  core.invoke(blockToggle,"setTextAndCheck","Объединять длинные сообщения",prefs.getBoolean("block_long",true),false);add(controls,blockToggle);
  controls.addView(blockParameters,new LinearLayout.LayoutParams(-1,-2));
  parameter(blockParameters,"Минимум символов","block_min",new int[]{3,10,30,100},3,false);
  parameter(blockParameters,"Пауза между сообщениями","block_pause",pauses,3,true);
  blockParameters.setVisibility(prefs.getBoolean("block_long",true)?View.VISIBLE:View.GONE);
  blockToggle.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{boolean enabled=!prefs.getBoolean("block_long",true);prefs.edit().putBoolean("block_long",enabled).apply();core.invoke(blockToggle,"setChecked",enabled);blockParameters.setVisibility(enabled?View.VISIBLE:View.GONE);style();apply();}catch(Exception ex){core.chatError(ex);}}});
  root.addView(footer(),new LinearLayout.LayoutParams(-1,-2));
  style();return root;
 }
 View footer()throws Exception{int accent=((Number)core.invoke(core.type("org.telegram.ui.ActionBar.Theme"),"getColor",((Number)core.read(core.type("org.telegram.ui.ActionBar.Theme"),"key_windowBackgroundWhiteBlueText")).intValue(),provider)).intValue();return new FeedbackButtons(core,context,account,accent,bg).create();}
 void parameter(final String title,final String key,final int[] values,final int fallback,final boolean seconds)throws Exception{
  parameter(parameters,title,key,values,fallback,seconds);
 }
 void parameter(LinearLayout target,final String title,final String key,final int[] values,final int fallback,final boolean seconds)throws Exception{
  final View row=cell(title,prefs.getInt(key,fallback)+(seconds?" сек":""));add(target,row);
  row.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{editor(row,title,key,values,fallback,seconds);}catch(Exception ex){core.chatError(ex);}}});
 }
 static int parseValue(String text,boolean seconds){
  int value=Integer.parseInt(text.trim());int min=seconds?1:3,max=seconds?86400:10000;
  if(value<min||value>max)throw new IllegalArgumentException();return value;
 }
 void editor(final View row,final String title,final String key,int[] presets,int fallback,final boolean seconds)throws Exception{
  LinearLayout body=new LinearLayout(context);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(20),dp(8),dp(20),dp(8));
  final EditText input=(EditText)core.type("org.telegram.ui.Components.EditTextBoldCursor").getConstructor(Context.class).newInstance(context);
  input.setTextSize(20);input.setTextColor(color);input.setSingleLine(true);input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
  input.setHint(seconds?"Секунды":key.equals("block_min")?"Количество символов":"Количество сообщений");input.setText(String.valueOf(prefs.getInt(key,fallback)));input.selectAll();
  body.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
  LinearLayout choices=new LinearLayout(context);choices.setGravity(Gravity.CENTER_VERTICAL);body.addView(choices,new LinearLayout.LayoutParams(-1,dp(44)));
  for(final int value:presets){TextView shortcut=new TextView(context);shortcut.setText(value+(seconds?" с":""));shortcut.setTextColor(color);shortcut.setTextSize(15);shortcut.setGravity(Gravity.CENTER);shortcut.setBackgroundDrawable(background());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));choices.addView(shortcut,lp);shortcut.setOnClickListener(new View.OnClickListener(){public void onClick(View v){input.setText(String.valueOf(value));input.setSelection(input.length());}});}
  Object builder=core.type("org.telegram.ui.ActionBar.AlertDialog$Builder").getConstructor(Context.class,core.type("org.telegram.ui.ActionBar.Theme$ResourcesProvider")).newInstance(context,provider);
  core.invoke(builder,"setTitle",title);core.invoke(builder,"setView",body);core.invoke(builder,"setPositiveButton","Сохранить",null);core.invoke(builder,"setNegativeButton","Отмена",null);
  final Dialog dialog=(Dialog)core.invoke(builder,"show");core.trackDialog(dialog);View save=(View)core.invoke(dialog,"getButton",DialogInterface.BUTTON_POSITIVE);
  save.setOnClickListener(new View.OnClickListener(){public void onClick(View v){int value;
   try{value=parseValue(input.getText().toString(),seconds);}catch(RuntimeException ex){input.setError(seconds?"Введите от 1 до 86400 секунд":key.equals("block_min")?"Введите от 3 до 10000 символов":"Введите от 3 до 10000 сообщений");return;}
   try{prefs.edit().putInt(key,value).apply();core.invoke(row,"setTextAndValue",title,value+(seconds?" сек":""),false);apply();dialog.dismiss();}catch(Exception ex){core.chatError(ex);}
  }});
  input.requestFocus();dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
 }
}
