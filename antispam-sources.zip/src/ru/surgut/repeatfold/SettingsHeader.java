package ru.surgut.repeatfold;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Framework root is safe to return to Chaquopy across core upgrades. */
final class SettingsHeader {
 final Core core;final Context context;final int account;final Object provider;final float density;
 SettingsHeader(Core c,Context ctx,int a,Object p){core=c;context=ctx;account=a;provider=p;density=ctx.getResources().getDisplayMetrics().density;}
 int dp(int n){return (int)(n*density+.5f);}
 int color(String key)throws Exception{Class<?> theme=core.type("org.telegram.ui.ActionBar.Theme");return ((Number)core.invoke(theme,"getColor",((Number)core.read(theme,key)).intValue(),provider)).intValue();}
 TextView text(String value,int size,int color){TextView t=new TextView(context);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setSingleLine(false);t.setEllipsize(null);t.setIncludeFontPadding(true);t.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));return t;}
 View create()throws Exception{
  final LinearLayout root=new LinearLayout(context);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(20),dp(20),dp(20),dp(24));root.setLayoutParams(new ViewGroup.LayoutParams(-1,-2));root.setClipChildren(false);root.setClipToPadding(false);
  final View icon=(View)core.type("org.telegram.ui.Components.BackupImageView").getConstructor(Context.class).newInstance(context);
  FrameLayout iconBox=new FrameLayout(context);iconBox.setClipChildren(false);iconBox.setClipToPadding(false);
  FrameLayout.LayoutParams iconParams=new FrameLayout.LayoutParams(dp(88),dp(88),Gravity.CENTER);
  iconBox.addView(icon,iconParams);root.addView(iconBox,new LinearLayout.LayoutParams(-1,dp(104)));
  core.invoke(core.invoke(icon,"getImageReceiver"),"setAspectFit",true);
  icon.setOnLongClickListener(new View.OnLongClickListener(){public boolean onLongClick(View v){try{Context ctx=context;while(ctx instanceof android.content.ContextWrapper&&!(ctx instanceof android.app.Activity)){Context next=((android.content.ContextWrapper)ctx).getBaseContext();if(next==ctx)break;ctx=next;}if(ctx instanceof android.app.Activity)core.previewUpdate((android.app.Activity)ctx);else throw new IllegalStateException("Нет активного окна");}catch(Exception ex){core.chatError(ex);}return true;}});

  int main=color("key_windowBackgroundWhiteBlackText"),gray=color("key_windowBackgroundWhiteGrayText");
  TextView title=text("Antispam",25,main);title.setTypeface(null,Typeface.BOLD);title.setPadding(0,dp(8),0,dp(6));root.addView(title);
  boolean ru=Locale.getDefault().getLanguage().equals("ru");
  root.addView(text(ru?"Сворачивает повторы и быстрый спам.\nНастраивается отдельно для каждого чата.":"Folds repeats and rapid spam.\nChoose which chats to protect.",14,gray));
  TextView owner=text("@lisurgut",14,gray);owner.setPadding(0,dp(8),0,0);root.addView(owner);
  root.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){
   boolean attached;int tries;
   final Runnable load=new Runnable(){public void run(){if(!attached||!core.running())return;try{
    Object media=core.invoke(core.type("org.telegram.messenger.MediaDataController"),"getInstance",account);
    Object set=core.invoke(media,"getStickerSetByName","SillyKittens6");if(set==null)set=core.invoke(media,"getStickerSetByEmojiOrName","SillyKittens6");
    if(set!=null){List<?> docs=(List<?>)core.read(set,"documents");if(!docs.isEmpty()){
     Object doc=docs.get(0),location=core.invoke(core.type("org.telegram.messenger.ImageLocation"),"getForDocument",doc);
     Object receiver=core.invoke(icon,"getImageReceiver");core.invoke(receiver,"setCurrentAccount",account);
     Class<?> loc=core.type("org.telegram.messenger.ImageLocation");
     icon.getClass().getMethod("setImage",loc,String.class,Drawable.class,Object.class).invoke(icon,location,"88_88",null,set);return;
    }}
    if(tries++==0)core.invoke(media,"loadStickersByEmojiOrName","SillyKittens6",false,true);
    if(tries<20)core.later(this,500);
   }catch(Exception ex){core.chatError(ex);}}};
   public void onViewAttachedToWindow(View v){attached=true;tries=0;load.run();}
   public void onViewDetachedFromWindow(View v){attached=false;}
  });return root;
 }
}
