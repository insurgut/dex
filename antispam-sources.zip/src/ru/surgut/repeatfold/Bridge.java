package ru.surgut.repeatfold;
import android.content.Context;
/** Python only sees boot-class values (void/int/String), never custom-loader instances. */
public final class Bridge {
 private static final Core CORE=new Core();
 private Bridge(){}
 public static int api(){return 2;}
 public static String version(){return CORE.version();}
 public static String lastError(){return CORE.lastError();}
 public static void configure(boolean enabled,int threshold,int window,int pause){CORE.configure(enabled,threshold,window,pause);}
 public static void start(Context context)throws Exception{CORE.start(context);}
 public static void offerUpdate(android.app.Activity activity,Runnable action)throws Exception{CORE.offerUpdate(activity,action);}
 public static void showChats(android.app.Activity activity)throws Exception{CORE.showChats(activity);}
 public static android.view.View settingsHeader(Context context,int account,Object provider)throws Exception{return CORE.settingsHeader(context,account,provider);}
 public static android.view.View settingsView(Context context,int account,Object provider)throws Exception{return CORE.settingsView(context,account,provider);}
 public static void migrateSettings(Context context,boolean enabled,int threshold,int window,int pause){CORE.migrateSettings(context,enabled,threshold,window,pause);}
 public static android.view.View feedbackView(Context context,int account,Object provider)throws Exception{return new android.widget.LinearLayout(context);}
 public static void setFeedbackSender(Runnable callback){CORE.setFeedbackSender(callback);}
 public static String feedbackPayload(){return CORE.feedbackPayload();}
 public static void feedbackResult(boolean success,String error){CORE.feedbackResult(success,error);}
 public static void setUpdateChecker(Runnable callback){CORE.setUpdateChecker(callback);}
 public static void stop(){CORE.stop();}
}
