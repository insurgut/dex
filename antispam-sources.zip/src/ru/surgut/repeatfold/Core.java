package ru.surgut.repeatfold;

import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.MotionEvent;
import android.widget.Toast;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import java.lang.reflect.*;
import java.util.*;
import java.io.StringWriter;
import java.io.PrintWriter;

/** All message, layout, drawing and touch hooks execute here, never in Python. */
public final class Core {
 public static final String VERSION="2.3.11";
 public int api(){return 1;}
 public String version(){return VERSION;}
 private Context context; private ClassLoader loader; private Class<?> cellClass,themeClass;
 private final Handler main=new Handler(Looper.getMainLooper());
 private final ArrayList<XC_MethodHook.Unhook> hooks=new ArrayList<>();
 private final WeakHashMap<View,State> states=new WeakHashMap<>();
 private final WeakHashMap<Object,Snapshot> snapshots=new WeakHashMap<>();
 private final WeakHashMap<Object,Boolean> pending=new WeakHashMap<>();
 private final HashMap<String,Field> fields=new HashMap<>();
 private final HashSet<String> absentFields=new HashSet<>();
 private final HashMap<String,Method> methods=new HashMap<>();
 private final LinkedHashSet<String> expanded=new LinkedHashSet<>();private final HashSet<String> errors=new HashSet<>();
 private boolean blockWidthRefreshPending;
 private boolean blockLong=true;private int blockMin=3,blockPause=3;
 private volatile boolean active=false;private boolean rapid=true; private int threshold=5,window=3,pause=2;
 private float radius,half,gap,edge,slop,textOffset;
 private final RectF capsule=new RectF();
 private Paint bg=new Paint(Paint.ANTI_ALIAS_FLAG),fg=new Paint(Paint.ANTI_ALIAS_FLAG);
 private Method measured,left,right,top,bottom,providerMethod,themeColor;
 private int inBg,outBg,inFg,outFg,emojiType; private View pressed; private float pressX,pressY;
 private String lastError="";
 private Class<?> emojiClass; private Method emojiMake,emojiAdd,emojiRemove;
 private final HashMap<String,android.graphics.drawable.Drawable> symbols=new HashMap<>();
 public void migrateSettings(Context ctx,boolean rapid,int threshold,int window,int pause){
  android.content.SharedPreferences prefs=ctx.getApplicationContext().getSharedPreferences("antispam_native_settings",0);
  if(!prefs.contains("rapid"))prefs.edit().putBoolean("rapid",rapid).putInt("threshold",threshold).putInt("window",window).putInt("pause",pause).apply();
  configure(prefs.getBoolean("rapid",true),prefs.getInt("threshold",5),prefs.getInt("window",3),prefs.getInt("pause",2));
 }
 public View settingsView(Context ctx,int account,Object provider)throws Exception{return new NativeSettings(this,ctx,account,provider).create();}
 public View settingsHeader(Context ctx,int account,Object provider)throws Exception{return new SettingsHeader(this,ctx,account,provider).create();}
 synchronized void later(Runnable task,long delay){if(active)main.postDelayed(task,delay);}
 boolean running(){return active;}
 private void symbol(View cell,State st,State old)throws Exception{
  if(emojiClass==null)return;
  if(st.role>1){int account=num(get(get(st.adapter.get(),"this$0"),"currentAccount"));String key=account+":"+st.opened;
   st.symbol=symbols.get(key);if(st.symbol==null){st.symbol=(android.graphics.drawable.Drawable)emojiMake.invoke(null,account,0,st.opened?5875078273775439450L:5875008416132370818L);symbols.put(key,st.symbol);}
  }
  if(old!=null&&old.symbol==st.symbol&&old.symbolAttached){st.symbolAttached=true;return;}
  if(old!=null&&old.symbol!=null&&old.symbolAttached){emojiRemove.invoke(old.symbol,cell);old.symbolAttached=false;}
  if(st.symbol!=null&&cell.getWindowToken()!=null){emojiAdd.invoke(st.symbol,cell);st.symbolAttached=true;}
 }
 private void releaseSymbol(View cell,State st){if(st!=null&&st.symbol!=null&&st.symbolAttached)try{emojiRemove.invoke(st.symbol,cell);st.symbolAttached=false;}catch(Exception ex){error(ex);}}

 private final HashSet<String> disabledChats=new HashSet<>();
 private final WeakHashMap<Object,String> adapterChats=new WeakHashMap<>();
 private android.app.Dialog chatSheet;
 private final ArrayList<android.app.Dialog> settingsDialogs=new ArrayList<>();
 void trackDialog(final android.app.Dialog dialog){settingsDialogs.add(dialog);dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener(){public void onDismiss(android.content.DialogInterface d){settingsDialogs.remove(dialog);}});}
 Object read(Object o,String n)throws Exception{return get(o,n);}
 Object invoke(Object o,String n,Object...a)throws Exception{return call(o,n,a);}
 Class<?> type(String n)throws Exception{return Class.forName(n,true,loader);}
 void chatError(Throwable e){error(e);}
 boolean chatEnabled(int account,long dialog){return !disabledChats.contains(account+":"+dialog);}
 void setChatEnabled(int account,long dialog,boolean enabled)throws Exception{
  String key=account+":"+dialog;if(enabled)disabledChats.remove(key);else disabledChats.add(key);
  StringBuilder saved=new StringBuilder();for(String k:disabledChats)saved.append(k).append(';');
  context.getSharedPreferences("repeat_fold_chat_settings",0).edit().putString("disabled",saved.toString()).apply();
  for(Object a:new ArrayList<Object>(adapterChats.keySet()))if(key.equals(adapterChats.get(a))){snapshots.remove(a);call(a,"notifyDataSetChanged");}
 }
 void feedbackClosed(FeedbackForm form){if(feedbackForm==form)feedbackForm=null;}
 void noticeClosed(UpdateNotice notice){if(updateNotice==notice)updateNotice=null;}
 void chatClosed(android.app.Dialog dialog){if(chatSheet==dialog)chatSheet=null;}
 private final WeakHashMap<View,android.graphics.drawable.Drawable> settingsEmojis=new WeakHashMap<>();
 void attachSettingsEmoji(android.graphics.drawable.Drawable emoji,View view)throws Exception{if(!active)return;call(emoji,"addView",view);settingsEmojis.put(view,emoji);}
 void detachSettingsEmoji(android.graphics.drawable.Drawable emoji,View view)throws Exception{settingsEmojis.remove(view);call(emoji,"removeView",view);}
 private FeedbackForm feedbackForm;
 // Compatibility for installed 2.3.0 loaders; transport no longer calls Python.
 public void setFeedbackSender(Runnable callback){}
 public String feedbackPayload(){return "";}
 public void feedbackResult(boolean success,String error){}
 void showFeedback(android.app.Activity activity,int account,boolean bug)throws Exception{if(!active)return;if(feedbackForm!=null)feedbackForm.close();feedbackForm=new FeedbackForm(this,activity,account,bug);feedbackForm.show();}
 void submitFeedback(int account,boolean bug,String text,java.util.ArrayList<String> files)throws Exception{if(feedbackForm==null||feedbackForm.closed)return;feedbackForm.sender=new FeedbackSender(this,account,feedbackForm);feedbackForm.sender.send(bug,text,new java.util.ArrayList<String>(files));}
 private Runnable updateChecker;
 private final Runnable updateTick=new Runnable(){public void run(){if(!active)return;try{if(updateChecker!=null)updateChecker.run();}catch(Throwable ex){error(ex);}if(active)main.postDelayed(this,30000);}};
 public void setUpdateChecker(Runnable checker){updateChecker=checker;main.removeCallbacks(updateTick);if(active&&checker!=null)main.postDelayed(updateTick,30000);}
 private UpdateNotice updateNotice;
 void previewUpdate(android.app.Activity activity)throws Exception{if(!active||activity==null||activity.isFinishing())return;if(updateNotice!=null)updateNotice.dismiss();updateNotice=new UpdateNotice(this,activity,new Runnable(){public void run(){}},true);updateNotice.show();}
 public void offerUpdate(android.app.Activity activity,Runnable action)throws Exception{if(!active||activity==null||activity.isFinishing())return;if(updateNotice!=null)updateNotice.dismiss();updateNotice=new UpdateNotice(this,activity,action);updateNotice.show();}
 public void showChats(android.app.Activity activity)throws Exception{
  if(!active||activity==null||activity.isFinishing())return;
  if(chatSheet!=null)chatSheet.dismiss();chatSheet=new ChatPicker(this,activity).show();
 }
 private String adapterChat(Object a)throws Exception{
  String key=adapterChats.get(a);if(key==null){Object chat=get(a,"this$0");key=num(get(chat,"currentAccount"))+":"+lng(get(chat,"dialog_id"));adapterChats.put(a,key);}return key;
 }

 private static final class State {
  int naturalBubbleWidth,bubbleViewport;boolean bubbleAdjusted,originalDrawBottom;Record record;
  int nativeHeight,totalHeight;boolean below;float badgeX,badgeY;android.graphics.drawable.Drawable symbol;boolean symbolAttached;
  java.lang.ref.WeakReference<Object> adapter; int messageId,index,role,previous; boolean out,opened,blockEligible,blockTop,blockBottom; String group,label; int bgColor,fgColor;android.graphics.ColorFilter symbolColor;
  State(Object a,int i,int r){adapter=new java.lang.ref.WeakReference<Object>(a);index=i;role=r;label=r>99?"99+":String.valueOf(r);}
 }
 private static final class Record {
  BlockWidth blockWidth;int naturalWidth,widthViewport;
  int id,date,edited,type; boolean out,blockEligible; String text,exact,actor; long dialog;
 }
 private static final class Snapshot {
  int first,last; int size; java.lang.ref.WeakReference<Object> list; Record[] records; int[] counts,heads,links; Map<Integer,Integer> positions=new HashMap<>();
 }
 private Field field(Class<?> cls,String name)throws Exception{
  String k=cls.getName()+"#"+name; Field f=fields.get(k);if(f!=null)return f;if(absentFields.contains(k))throw new NoSuchFieldException(k);
  Class<?> c=cls;while(c!=null){try{f=c.getDeclaredField(name);f.setAccessible(true);fields.put(k,f);return f;}catch(NoSuchFieldException e){c=c.getSuperclass();}}
  absentFields.add(k);throw new NoSuchFieldException(k);
 }
 private Object get(Object o,String name)throws Exception{return field(o instanceof Class?(Class<?>)o:o.getClass(),name).get(o instanceof Class?null:o);}
 private Object optional(Object o,String name){if(o==null||absentFields.contains((o instanceof Class?((Class<?>)o).getName():o.getClass().getName())+"#"+name))return null;try{return get(o,name);}catch(Exception e){return null;}}
 private static int num(Object o){return o instanceof Number?((Number)o).intValue():0;}
 private static long lng(Object o){return o instanceof Number?((Number)o).longValue():0;}
 private static String str(Object o){return o==null?"":String.valueOf(o);}
 private static boolean bool(Object o){return Boolean.TRUE.equals(o);}
 private Method exact(Class<?> c,String name,Class<?>...types)throws Exception{
  Method m=c.getDeclaredMethod(name,types);m.setAccessible(true);return m;
 }
 private Object call(Object o,String name,Object...args)throws Exception{
  Class<?> cls=o instanceof Class?(Class<?>)o:o.getClass();StringBuilder kb=new StringBuilder(cls.getName()).append('#').append(name);
  for(Object a:args)kb.append(':').append(a==null?"null":a.getClass().getName());String k=kb.toString();Method m=methods.get(k);
  if(m==null){for(Class<?> c=cls;c!=null&&m==null;c=c.getSuperclass())for(Method x:c.getDeclaredMethods()){
   if(!x.getName().equals(name)||x.getParameterTypes().length!=args.length)continue;
   Class<?>[] ts=x.getParameterTypes();boolean match=true;
   for(int i=0;i<ts.length;i++){if(args[i]==null){if(ts[i].isPrimitive())match=false;}
    else if(ts[i].isPrimitive()){Class<?> t=ts[i];if(t==boolean.class?! (args[i] instanceof Boolean):t==int.class?! (args[i] instanceof Integer):t==long.class?! (args[i] instanceof Long):t==float.class?! (args[i] instanceof Float):t==double.class?! (args[i] instanceof Double):true)match=false;}
    else if(!ts[i].isInstance(args[i]))match=false;}
   if(match){m=x;break;}}
   if(m==null)throw new NoSuchMethodException(k);m.setAccessible(true);methods.put(k,m);
  }return m.invoke(o instanceof Class?null:o,args);
 }
 private void error(Throwable e){
  if(e instanceof InvocationTargetException&&((InvocationTargetException)e).getCause()!=null)e=((InvocationTargetException)e).getCause();
  String signature=e.getClass().getName()+":"+(e.getStackTrace().length>0?e.getStackTrace()[0].toString():"");if(errors.size()>=64||!errors.add(signature))return;
  StringWriter s=new StringWriter();e.printStackTrace(new PrintWriter(s));lastError="RepeatFold DEX "+VERSION+"\n"+s;
  final String report=lastError;try{android.util.Log.e("Antispam",report);}catch(Throwable ignored){}main.post(new Runnable(){public void run(){try{ClipboardManager cb=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);cb.setPrimaryClip(ClipData.newPlainText("RepeatFold",report));Toast.makeText(context,"Антиспам: ошибка скопирована",Toast.LENGTH_LONG).show();}catch(Throwable ignored){}}});
 }
 public String lastError(){return lastError;}
 public void configure(boolean enabled,int threshold,int window,int pause){if(context!=null){android.content.SharedPreferences p=context.getSharedPreferences("antispam_native_settings",0);blockLong=p.getBoolean("block_long",true);blockMin=Math.max(3,p.getInt("block_min",3));blockPause=Math.max(1,p.getInt("block_pause",3));}this.rapid=enabled;this.threshold=Math.max(3,threshold);this.window=Math.max(1,window);this.pause=Math.max(1,pause);if(active){expanded.clear();final ArrayList<Object> as=new ArrayList<>(snapshots.keySet());snapshots.clear();main.post(new Runnable(){public void run(){for(Object a:as)try{Snapshot s=snapshot(a,-1);notifyRows(a,0,s.size);}catch(Throwable e){error(e);}}});}}
 private abstract class Hook extends XC_MethodHook {
  void before(MethodHookParam p)throws Throwable{} void after(MethodHookParam p)throws Throwable{}
  @Override protected final void beforeHookedMethod(MethodHookParam p){if(active)try{before(p);}catch(Throwable e){error(e);}}
  @Override protected final void afterHookedMethod(MethodHookParam p){if(active)try{after(p);}catch(Throwable e){error(e);}}
 }
 private void hook(Method m,Hook h){m.setAccessible(true);hooks.add(XposedBridge.hookMethod(m,h));}
 public void start(Context ctx)throws Exception{
  if(active)return;context=ctx.getApplicationContext();loader=context.getClassLoader();errors.clear();disabledChats.clear();for(String k:context.getSharedPreferences("repeat_fold_chat_settings",0).getString("disabled","").split(";"))if(!k.isEmpty())disabledChats.add(k);
  cellClass=Class.forName("org.telegram.ui.Cells.ChatMessageCell",true,loader);themeClass=Class.forName("org.telegram.ui.ActionBar.Theme",true,loader);
  Class<?> adapter=Class.forName("org.telegram.ui.ChatActivity$ChatActivityAdapter",true,loader);
  measured=exact(View.class,"setMeasuredDimension",int.class,int.class);
  left=exact(cellClass,"getBackgroundDrawableLeft");right=exact(cellClass,"getBackgroundDrawableRight");top=exact(cellClass,"getBackgroundDrawableTop");bottom=exact(cellClass,"getBackgroundDrawableBottom");
  providerMethod=exact(cellClass,"getResourcesProvider");
  Class<?> provider=Class.forName("org.telegram.ui.ActionBar.Theme$ResourcesProvider",true,loader);themeColor=exact(themeClass,"getColor",int.class,provider);
  Object emojiConstant=optional(Class.forName("org.telegram.messenger.MessageObject",true,loader),"TYPE_EMOJIS");emojiType=emojiConstant==null?-1:num(emojiConstant);
  inBg=num(get(themeClass,"key_chat_inBubble"));outBg=num(get(themeClass,"key_chat_outBubble"));inFg=num(get(themeClass,"key_chat_messageTextIn"));outFg=num(get(themeClass,"key_chat_messageTextOut"));
  float density=context.getResources().getDisplayMetrics().density;radius=15*density;half=28*density;gap=4*density;edge=2*density;slop=8*density;fg.setTextSize(12*density);fg.setTextAlign(Paint.Align.CENTER);fg.setStrokeWidth(2*density);Paint.FontMetrics fm=fg.getFontMetrics();textOffset=-(fm.ascent+fm.descent)/2;
  try{emojiClass=Class.forName("org.telegram.ui.Components.AnimatedEmojiDrawable",true,loader);
  emojiMake=exact(emojiClass,"make",int.class,int.class,long.class);emojiAdd=exact(emojiClass,"addView",View.class);emojiRemove=exact(emojiClass,"removeView",View.class);}catch(Exception ex){emojiClass=null;error(ex);}
  android.content.SharedPreferences blockPrefs=context.getSharedPreferences("antispam_native_settings",0);blockLong=blockPrefs.getBoolean("block_long",true);blockMin=Math.max(3,blockPrefs.getInt("block_min",3));blockPause=Math.max(1,blockPrefs.getInt("block_pause",3));
  active=true;
  try{
   boolean bound=false;for(Method m:adapter.getDeclaredMethods())if(m.getName().equals("onBindViewHolder")&&!m.isBridge()&&m.getParameterTypes().length==2&&m.getParameterTypes()[1]==int.class){bound=true;hook(m,new Hook(){
    void before(MethodHookParam p)throws Throwable{View cell=(View)get(p.args[0],"itemView");if(!cellClass.isInstance(cell))return;restoreBubble(cell,states.get(cell));Object a=p.thisObject;if(disabledChats.contains(adapterChat(a))){State previous=states.remove(cell);releaseSymbol(cell,previous);if(previous!=null)restore(cell);return;}ArrayList<?> list=messages(a);int i=num(p.args[1])-num(get(a,"messagesStartRow"));if(i<0||i>=list.size()){releaseSymbol(cell,states.get(cell));restore(cell);states.remove(cell);return;}
     Snapshot ss=snapshot(a,i);int role=role(a,ss,i);State old=states.get(cell);State st=new State(a,i,role);st.record=ss.records[i];st.messageId=ss.records[i].id;st.out=ss.records[i].out;st.blockEligible=blockLong&&ss.records[i].blockEligible&&role==1;st.blockTop=(ss.links[i]&1)!=0;st.blockBottom=(ss.links[i]&2)!=0;st.group=group(a,ss,i);st.opened=expanded.contains(st.group);st.previous=old==null?1:old.role;if(old!=null){st.nativeHeight=old.nativeHeight;st.totalHeight=old.totalHeight;st.below=old.below;st.badgeX=old.badgeX;st.badgeY=old.badgeY;}states.put(cell,st);try{symbol(cell,st,old);}catch(Exception ex){releaseSymbol(cell,old);st.symbol=null;error(ex);}
     // Always let native binding set MessageObject before RecyclerView attaches the cell.
    }
    void after(MethodHookParam p)throws Throwable{View cell=(View)get(p.args[0],"itemView");State st=states.get(cell);if(st==null)return;apply(cell,st,st.previous);if(st.role>1)palette(cell,st);}
   });}if(!bound)throw new NoSuchMethodException("onBindViewHolder");
   // Native bubble grouping also runs when an unattached/frozen cell binds later.
   for(Method m:cellClass.getDeclaredMethods())if((m.getName().equals("setMessageObject")||m.getName().equals("setMessageContent"))&&m.getParameterTypes().length>=5&&m.getParameterTypes()[2]==boolean.class&&m.getParameterTypes()[3]==boolean.class)hook(m,new Hook(){void before(MethodHookParam p)throws Throwable{State st=states.get((View)p.thisObject);if(st==null||!st.blockEligible||p.args[0]==null||id(p.args[0])!=st.messageId||p.args[1]!=null)return;p.args[2]=Boolean.valueOf(st.blockBottom);p.args[3]=Boolean.valueOf(st.blockTop);}});
   // Hide only the native metadata renderer; no changes to MessageObject or shared Paints.
   boolean metadataHooked=false;
   for(Method m:cellClass.getDeclaredMethods())if(m.getName().equals("drawTimeInternal")&&m.getReturnType()==void.class&&m.getParameterTypes().length>0&&m.getParameterTypes()[0]==Canvas.class){metadataHooked=true;hook(m,new Hook(){void before(MethodHookParam p){State st=states.get((View)p.thisObject);if(st!=null&&st.blockEligible&&st.blockBottom)p.setResult(null);}});}
   if(!metadataHooked)for(Method m:cellClass.getDeclaredMethods())if(m.getName().equals("drawTime")&&m.getReturnType()==void.class&&m.getParameterTypes().length>0&&m.getParameterTypes()[0]==Canvas.class){metadataHooked=true;hook(m,new Hook(){void before(MethodHookParam p){State st=states.get((View)p.thisObject);if(st!=null&&st.blockEligible&&st.blockBottom)p.setResult(null);}});}
   if(!metadataHooked)error(new NoSuchMethodException("ChatMessageCell time renderer: drawTimeInternal/drawTime"));
   hook(exact(cellClass,"onAttachedToWindow"),new Hook(){void after(MethodHookParam p)throws Throwable{View cell=(View)p.thisObject;State st=states.get(cell);if(st!=null&&st.symbol!=null&&!st.symbolAttached){emojiAdd.invoke(st.symbol,cell);st.symbolAttached=true;}}});
   hook(exact(cellClass,"onDetachedFromWindow"),new Hook(){void before(MethodHookParam p){releaseSymbol((View)p.thisObject,states.get((View)p.thisObject));}});
   hook(exact(cellClass,"onMeasure",int.class,int.class),new Hook(){void before(MethodHookParam p)throws Throwable{State st=states.get((View)p.thisObject);if(st!=null&&st.role==-1){measured.invoke(p.thisObject,num(p.args[0])&0x3fffffff,0);p.setResult(null);}}void after(MethodHookParam p)throws Throwable{View cell=(View)p.thisObject;State st=states.get(cell);if(st!=null)sizeBlock(cell,st);if(st==null||st.role<2)return;int width=cell.getMeasuredWidth(),height=cell.getMeasuredHeight();float l=num(left.invoke(cell)),r=num(right.invoke(cell));if(st.out){float delta=width-num(get(cell,"layoutWidth"));l+=delta;r+=delta;}st.nativeHeight=height;st.below=BadgePlacement.below(width,l,r,st.out,half,gap,edge);st.badgeX=BadgePlacement.x(width,l,r,st.out,st.below,half,gap,edge);st.badgeY=BadgePlacement.y(num(top.invoke(cell)),num(bottom.invoke(cell)),height,st.below,radius,gap*2,edge);st.totalHeight=st.below?height+(int)Math.ceil(gap*2+radius*2+edge*3):height;measured.invoke(cell,width,st.totalHeight);}});
   hook(exact(cellClass,"onLayout",boolean.class,int.class,int.class,int.class,int.class),new Hook(){
    void before(MethodHookParam p)throws Throwable{View cell=(View)p.thisObject;State st=states.get(cell);if(st!=null&&st.role>1&&st.nativeHeight>0)measured.invoke(cell,cell.getMeasuredWidth(),st.nativeHeight);}
    void after(MethodHookParam p)throws Throwable{View cell=(View)p.thisObject;State st=states.get(cell);if(st!=null&&st.role>1&&st.nativeHeight>0){measured.invoke(cell,cell.getMeasuredWidth(),st.totalHeight);float l=num(left.invoke(cell)),r=num(right.invoke(cell));boolean below=BadgePlacement.below(cell.getMeasuredWidth(),l,r,st.out,half,gap,edge);int total=below?st.nativeHeight+(int)Math.ceil(gap*2+radius*2+edge*3):st.nativeHeight;boolean changed=st.below!=below||st.totalHeight!=total;st.below=below;st.totalHeight=total;measured.invoke(cell,cell.getMeasuredWidth(),total);if(changed){final java.lang.ref.WeakReference<View> ref=new java.lang.ref.WeakReference<View>(cell);main.post(new Runnable(){public void run(){View v=ref.get();if(active&&v!=null){v.requestLayout();v.invalidate();}}});}st.badgeX=BadgePlacement.x(cell.getMeasuredWidth(),l,r,st.out,st.below,half,gap,edge);st.badgeY=BadgePlacement.y(num(top.invoke(cell)),num(bottom.invoke(cell)),st.nativeHeight,st.below,radius,gap*2,edge);}}
   });
   hook(exact(cellClass,"setAlpha",float.class),new Hook(){void before(MethodHookParam p){State st=states.get((View)p.thisObject);if(st!=null&&st.role==-2)p.args[0]=Float.valueOf(Math.min(((Number)p.args[0]).floatValue(),.45f));}});
   hook(exact(cellClass,"onDraw",Canvas.class),new Hook(){void after(MethodHookParam p)throws Throwable{View cell=(View)p.thisObject;State st=states.get(cell);if(st==null||st.role<2||cell.getMeasuredHeight()==0)return;draw((Canvas)p.args[0],cell,st);}});
   hook(exact(cellClass,"onTouchEvent",MotionEvent.class),new Hook(){void before(MethodHookParam p)throws Throwable{touch(p);}});
   if(updateChecker!=null)main.postDelayed(updateTick,30000);
   try{hook(exact(adapter,"updateRowsInternal"),new Hook(){void after(MethodHookParam p){queueRefresh(p.thisObject);}});}catch(NoSuchMethodException ignored){}
  }catch(Exception e){stop();throw e;}
 }
 private ArrayList<?> messages(Object a)throws Exception{if(bool(optional(a,"isFrozen")))return (ArrayList<?>)get(a,"frozenMessages");if(bool(optional(a,"isFiltered")))return (ArrayList<?>)get(a,"filteredMessages");return (ArrayList<?>)get(get(a,"this$0"),"messages");}
 private static String peer(Object p,Core c){return lng(c.optional(p,"user_id"))+","+lng(c.optional(p,"chat_id"))+","+lng(c.optional(p,"channel_id"));}
 private Record record(Object obj)throws Exception{
  Object m=get(obj,"messageOwner");Record r=new Record();r.id=num(get(m,"id"));r.date=num(get(m,"date"));r.edited=num(optional(m,"edit_date"));r.text=str(optional(m,"message"));r.type=num(get(obj,"type"));r.dialog=lng(call(obj,"getDialogId"));r.out=bool(call(obj,"isOutOwner"));
  if(r.id<=0||optional(m,"fwd_from")!=null||lng(optional(m,"grouped_id"))!=0)return r;
  String content=null;boolean emoji=r.type!=0&&bool(call(obj,"isAnimatedEmoji"));Object media=optional(m,"media");
  // TYPE_EMOJIS is resolved from the client instead of hardcoded.
  if(r.type==0||r.type==emojiType||emoji){if(r.text.isEmpty()||!emoji&&media!=null&&!media.getClass().getSimpleName().endsWith("messageMediaEmpty"))return r;content="text:"+r.text;r.blockEligible=Grouping.longText(r.text,blockMin);}
  else if(bool(call(obj,"isSticker"))||bool(call(obj,"isAnimatedSticker"))||bool(call(obj,"isVideoSticker"))||bool(call(obj,"isGif"))){Object doc=call(obj,"getDocument");if(doc==null||lng(optional(doc,"id"))==0)return r;content=(bool(call(obj,"isGif"))?"gif:":"sticker:")+lng(get(doc,"id"))+":"+r.text;}
  else return r;
  Object reply=optional(m,"reply_to");String replyKey=str(optional(reply,"reply_to_msg_id"))+":"+str(optional(reply,"reply_to_top_id"))+":"+str(optional(reply,"quote_text"));
  r.actor=peer(optional(m,"from_id"),this)+":"+r.out+":"+r.dialog+":"+replyKey+":"+(r.date/86400);
  StringBuilder ents=new StringBuilder();Object en=optional(m,"entities");if(en instanceof List)for(Object e:(List<?>)en)ents.append(e.getClass().getName()).append(':').append(num(optional(e,"offset"))).append(':').append(num(optional(e,"length"))).append(':').append(lng(optional(e,"document_id"))).append(':').append(str(optional(e,"url"))).append(':').append(str(optional(e,"user_id"))).append(';');
  r.exact=content+"\u0000"+r.actor+"\u0000"+ents;return r;
 }
 private int id(Object obj)throws Exception{return num(get(get(obj,"messageOwner"),"id"));}
 private boolean edited(Record r,Object obj)throws Exception{Object m=get(obj,"messageOwner");return r.id!=num(get(m,"id"))||r.edited!=num(optional(m,"edit_date"))||!r.text.equals(str(optional(m,"message")));}
 private Snapshot snapshot(Object a,int index)throws Exception{
  ArrayList<?> list=messages(a);int n=list.size(),first=n>0?id(list.get(0)):0,last=n>0?id(list.get(n-1)):0;Snapshot old=snapshots.get(a);Record[] rs=null;
  if(old!=null&&old.list.get()==list&&old.size==n&&old.first==first&&old.last==last){
   ArrayList<Integer> edits=new ArrayList<>();for(int i=index<0?0:Math.max(0,index-1);i<(index<0?n:Math.min(n,index+2));i++)if(edited(old.records[i],list.get(i)))edits.add(i);
   if(edits.isEmpty())return old;rs=old.records.clone();for(int i:edits)rs[i]=record(list.get(i));
  }else if(old!=null&&old.list.get()==list){int delta=n-old.size;
   if(delta>0&&delta<=64&&old.size>0&&last==old.last&&id(list.get(delta))==old.first){rs=new Record[n];System.arraycopy(old.records,0,rs,delta,old.size);for(int i=0;i<delta;i++)rs[i]=record(list.get(i));}
   else if(delta>0&&old.size>0&&first==old.first&&id(list.get(old.size-1))==old.last){rs=Arrays.copyOf(old.records,n);for(int i=old.size;i<n;i++)rs[i]=record(list.get(i));}
   else if(delta<0&&n>0&&last==old.last&&old.records[-delta].id==first)rs=Arrays.copyOfRange(old.records,-delta,old.size);
  }if(rs==null){rs=new Record[n];for(int i=0;i<n;i++)rs[i]=record(list.get(i));}
  Snapshot s=new Snapshot();s.list=new java.lang.ref.WeakReference<Object>(list);s.size=n;s.first=first;s.last=last;s.records=rs;s.counts=new int[n];s.heads=new int[n];Arrays.fill(s.counts,1);
  for(int i=0;i<n;i++){s.heads[i]=i;s.positions.put(rs[i].id,i);}
  String[] exacts=new String[n],actors=new String[n];int[] dates=new int[n];for(int i=0;i<n;i++){exacts[i]=blockLong&&rs[i].blockEligible?null:rs[i].exact;actors[i]=blockLong&&rs[i].blockEligible?null:rs[i].actor;dates[i]=rs[i].date;}
  s.counts=Grouping.counts(exacts,actors,dates,rapid,threshold,window,pause);for(int i=0;i<n;i++)if(s.counts[i]>1)for(int j=i+1;j<i+s.counts[i];j++)s.heads[j]=i;
  String[] blockActors=new String[n],blockExacts=new String[n];for(int i=0;i<n;i++){blockActors[i]=rs[i].blockEligible?rs[i].actor:null;blockExacts[i]=rs[i].exact;}s.links=Grouping.links(blockExacts,blockActors,dates,s.counts,blockLong,blockPause);
  // Shared width cache for each contiguous visual block. Existing records retain native measurements.
  for(int start=0;start<n;){int end=start+1;while(end<n&&(s.links[end-1]&1)!=0)end++;BlockWidth width=end-start>1?new BlockWidth():null;for(int j=start;j<end;j++){rs[j].blockWidth=width;if(width!=null&&rs[j].naturalWidth>0)width.observe(rs[j].widthViewport,rs[j].naturalWidth);}start=end;}
  snapshots.put(a,s);queueBlockWidths();return s;
 }
 private String group(Object a,Snapshot s,int i){Record r=s.records[s.heads[i]];return System.identityHashCode(a)+":"+r.dialog+":"+r.id;}
 private int role(Object a,Snapshot s,int i){int c=s.counts[i];return c==-1&&expanded.contains(group(a,s,i))?-2:c;}
 private void apply(View cell,State st,int previous)throws Exception{
  int visibility=st.role==-1?View.INVISIBLE:View.VISIBLE;if(cell.getVisibility()!=visibility)cell.setVisibility(visibility);float alpha=st.role==-2?.45f:1f;if(Math.abs(cell.getAlpha()-alpha)>.005f)cell.setAlpha(alpha);
  if(st.role==-1||previous==-1){try{Object image=call(cell,"getPhotoImage");call(image,"setVisible",st.role!=-1,false);if(st.role==-1)call(image,"stopAnimation");}catch(NoSuchMethodException ignored){}}
  if(st.role!=previous){cell.requestLayout();cell.invalidate();}
 }
 private void restore(View cell){restoreBubble(cell,states.get(cell));cell.setVisibility(View.VISIBLE);cell.setAlpha(1f);try{call(call(cell,"getPhotoImage"),"setVisible",true,false);}catch(Exception ignored){}cell.requestLayout();cell.invalidate();}
 private void queueBlockWidths(){if(blockWidthRefreshPending)return;blockWidthRefreshPending=true;main.post(new Runnable(){public void run(){blockWidthRefreshPending=false;if(!active)return;for(View v:new ArrayList<View>(states.keySet())){State st=states.get(v);if(st!=null)try{sizeBlock(v,st);}catch(Exception ex){error(ex);}}}});}
 private void restoreBubble(View cell,State st){if(st==null||!st.bubbleAdjusted)return;try{field(cellClass,"backgroundWidth").setInt(cell,st.naturalBubbleWidth);field(cellClass,"drawPinnedBottom").setBoolean(cell,st.originalDrawBottom);field(cellClass,"forcedLayout").setBoolean(cell,true);}catch(Exception ex){error(ex);}st.bubbleAdjusted=false;}
 private void sizeBlock(final View cell,final State st)throws Exception{
  if(!st.blockEligible||(!st.blockTop&&!st.blockBottom)||st.record==null||st.record.blockWidth==null)return;
  int viewport=cell.getMeasuredWidth();if(viewport<=0)return;
  if(st.bubbleViewport!=viewport){st.bubbleViewport=viewport;st.naturalBubbleWidth=0;st.bubbleAdjusted=false;}
  if(st.naturalBubbleWidth==0){st.naturalBubbleWidth=num(get(cell,"backgroundWidth"));st.originalDrawBottom=bool(get(cell,"drawPinnedBottom"));}
  if(st.naturalBubbleWidth<=0)return;
  int canonical=st.naturalBubbleWidth+(st.originalDrawBottom?0:(int)(context.getResources().getDisplayMetrics().density*6+.5f));
  st.record.naturalWidth=canonical;st.record.widthViewport=viewport;
  final BlockWidth width=st.record.blockWidth;boolean changed=width.observe(viewport,canonical);
  int target=width.value(viewport);boolean redraw=num(get(cell,"backgroundWidth"))!=target||!bool(get(cell,"drawPinnedBottom"));
  field(cellClass,"backgroundWidth").setInt(cell,target);field(cellClass,"drawPinnedBottom").setBoolean(cell,true);st.bubbleAdjusted=true;
  if(redraw){field(cellClass,"forcedLayout").setBoolean(cell,true);cell.requestLayout();cell.invalidate();}
  if(changed&&!width.pending){width.pending=true;main.post(new Runnable(){public void run(){width.pending=false;if(!active)return;for(View v:new ArrayList<View>(states.keySet())){State other=states.get(v);if(other!=null&&other.record!=null&&other.record.blockWidth==width){try{sizeBlock(v,other);v.requestLayout();v.invalidate();}catch(Exception ex){error(ex);}}}}});}
 }
 private void palette(View cell,State st)throws Exception{Object p=providerMethod.invoke(cell);st.bgColor=num(themeColor.invoke(null,st.out?outBg:inBg,p));st.fgColor=num(themeColor.invoke(null,st.out?outFg:inFg,p));st.symbolColor=new android.graphics.PorterDuffColorFilter(st.fgColor,android.graphics.PorterDuff.Mode.SRC_IN);}
 private float cx(View cell,State st){return st.badgeX;}
 private float cy(View cell,State st){return st.badgeY;}
 private void draw(Canvas c,View cell,State st)throws Exception{
  float x=cx(cell,st),y=cy(cell,st);bg.setColor(st.bgColor);fg.setColor(st.fgColor);capsule.set(x-half,y-radius,x+half,y+radius);c.drawRoundRect(capsule,radius,radius,bg);float d=radius/15; // density
  float ax=x+13*d;int saved=c.save();boolean drawn=false;
  try{if(st.symbol!=null){st.symbol.setColorFilter(st.symbolColor);float size=18*d;st.symbol.setBounds((int)(ax-size/2),(int)(y-size/2),(int)(ax+size/2),(int)(y+size/2));st.symbol.draw(c);drawn=true;}}catch(RuntimeException ex){releaseSymbol(cell,st);st.symbol=null;error(ex);}finally{c.restoreToCount(saved);}
  if(!drawn){float v=st.opened?-1:1;c.drawLine(ax-4*d,y-2*d*v,ax,y+2*d*v,fg);c.drawLine(ax,y+2*d*v,ax+4*d,y-2*d*v,fg);}
  c.drawText(st.label,x-8*d,y+textOffset,fg);

 }
 private void touch(XC_MethodHook.MethodHookParam p)throws Exception{
  View cell=(View)p.thisObject;MotionEvent e=(MotionEvent)p.args[0];int action=e.getActionMasked();State st=states.get(cell);
  if(action==MotionEvent.ACTION_DOWN){if(st==null||st.role<2)return;float x=cx(cell,st),y=cy(cell,st),dx=Math.max(Math.abs(e.getX()-x)-(half-radius),0);if(dx*dx+(e.getY()-y)*(e.getY()-y)>(radius+edge)*(radius+edge))return;pressed=cell;pressX=e.getX();pressY=e.getY();if(cell.getParent()!=null)cell.getParent().requestDisallowInterceptTouchEvent(true);p.setResult(true);return;}
  if(pressed!=cell)return;float dx=e.getX()-pressX,dy=e.getY()-pressY;boolean moved=dx*dx+dy*dy>slop*slop;
  if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL||moved){pressed=null;if(cell.getParent()!=null)cell.getParent().requestDisallowInterceptTouchEvent(false);if(action==MotionEvent.ACTION_UP&&!moved&&st!=null){if(!expanded.remove(st.group)){expanded.add(st.group);while(expanded.size()>512)expanded.remove(expanded.iterator().next());}final Object a=st.adapter.get();if(a==null)return;final int mid=st.messageId;main.post(new Runnable(){public void run(){if(!active)return;try{Snapshot s=snapshot(a,-1);Integer i=s.positions.get(mid);if(i!=null&&s.counts[i]>1)notifyRows(a,i,s.counts[i]);}catch(Throwable ex){error(ex);}}});}}
  p.setResult(true);
 }
 private void notifyRows(Object a,int start,int length)throws Exception{if(length>0)call(a,"notifyItemRangeChanged",num(get(a,"messagesStartRow"))+start,length);}
 private void queueRefresh(final Object a){if(pending.containsKey(a))return;pending.put(a,true);final Snapshot old=snapshots.get(a);final HashSet<String> open=new HashSet<>(expanded);
  main.postDelayed(new Runnable(){public void run(){pending.remove(a);if(!active)return;try{Snapshot next=snapshot(a,-1);if(next==old)return;HashMap<Integer,Integer> roles=new HashMap<>(),links=new HashMap<>();if(old!=null)for(int i=0;i<old.size;i++){roles.put(old.records[i].id,old.counts[i]==-1&&open.contains(group(a,old,i))?-2:old.counts[i]);links.put(old.records[i].id,old.links[i]);}int start=-1;
   for(int i=0;i<=next.size;i++){boolean changed=i<next.size&&(!Integer.valueOf(role(a,next,i)).equals(roles.containsKey(next.records[i].id)?roles.get(next.records[i].id):Integer.valueOf(1))||!Integer.valueOf(next.links[i]).equals(links.containsKey(next.records[i].id)?links.get(next.records[i].id):Integer.valueOf(0)));if(changed&&start<0)start=i;if(!changed&&start>=0){notifyRows(a,start,i-start);start=-1;}}
  }catch(Throwable e){error(e);}}},32);
 }
 public synchronized void stop(){blockWidthRefreshPending=false;active=false;updateChecker=null;if(feedbackForm!=null){try{feedbackForm.close();}catch(Throwable ignored){}feedbackForm=null;}if(updateNotice!=null){try{updateNotice.dismiss();}catch(Throwable ignored){}updateNotice=null;}active=false;for(android.app.Dialog d:new ArrayList<android.app.Dialog>(settingsDialogs))try{d.dismiss();}catch(Throwable ignored){}settingsDialogs.clear();if(chatSheet!=null){try{chatSheet.dismiss();}catch(Throwable ignored){}chatSheet=null;}adapterChats.clear();for(XC_MethodHook.Unhook h:hooks)if(h!=null)try{h.unhook();}catch(Throwable ignored){}hooks.clear();main.removeCallbacksAndMessages(null);pressed=null;final ArrayList<View> views=new ArrayList<>(states.keySet());final ArrayList<Object> as=new ArrayList<>(snapshots.keySet());for(View v:views){restoreBubble(v,states.get(v));releaseSymbol(v,states.get(v));}for(Map.Entry<View,android.graphics.drawable.Drawable> e:new ArrayList<Map.Entry<View,android.graphics.drawable.Drawable>>(settingsEmojis.entrySet()))try{call(e.getValue(),"removeView",e.getKey());}catch(Exception ignored){}settingsEmojis.clear();symbols.clear();states.clear();snapshots.clear();pending.clear();expanded.clear();for(View v:views)try{restore(v);}catch(Throwable ignored){}for(Object a:as)try{call(a,"notifyDataSetChanged");}catch(Exception ignored){}fields.clear();methods.clear();absentFields.clear();errors.clear();lastError="";main.removeCallbacksAndMessages(null);}
}
