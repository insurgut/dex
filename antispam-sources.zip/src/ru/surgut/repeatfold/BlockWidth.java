package ru.surgut.repeatfold;
/** Native width cache, independent of Android drawing and invalidated by viewport changes. */
public final class BlockWidth {
 private int viewport,max;boolean pending;
 public boolean observe(int viewport,int natural){if(viewport<=0||natural<=0)return false;if(this.viewport!=viewport){this.viewport=viewport;max=natural;return true;}if(natural>max){max=natural;return true;}return false;}
 public int value(int viewport){return this.viewport==viewport?max:0;}
}
