import base64
import hashlib
import os
import struct
import traceback
import zlib
import threading
import urllib.request
import json
import time

from base_plugin import BasePlugin, MethodHook
from types import SimpleNamespace
from java import jclass, jarray, jbyte, jint, dynamic_proxy
from android_utils import run_on_ui_thread, copy_to_clipboard
from client_utils import get_last_fragment
from file_utils import FilesController, get_plugins_dir
from ui.alert import AlertDialogBuilder
from ui.bulletin import BulletinHelper
from ui.settings import Text, Divider, Custom, SimpleSettingFactory

__id__ = "repeat_fold"
__name__ = "Antispam"
__description__ = "Сворачивает повторы и быстрый спам в выбранных чатах.\nFolds repeated messages and rapid spam in selected chats."
__author__ = "@lisurgut"
__version__ = "2.3.4"
__app_version__ = ">=12.5.1"
__sdk_version__ = ">=1.4.5.0"
__icon__ = "SillyKittens6/1"

# Bootstrap only. All message/layout/drawing/touch hooks are compiled Java.
EMBEDDED_CORE = "@@CORE@@"
MAX_CORE_BYTES = 1048576
CORE_URL = "https://github.com/insurgut/dex/raw/refs/heads/main/main.dexan"


class UpdateCheckAction(dynamic_proxy(jclass("java.lang.Runnable"))):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
    def run(self):
        if self.plugin.alive:
            self.plugin.download_core()


class UpdateAction(dynamic_proxy(jclass("java.lang.Runnable"))):
    def __init__(self, plugin, data, token):
        super().__init__()
        self.plugin, self.data, self.token = plugin, data, token
        self.consumed = False

    def run(self):
        plugin = self.plugin
        if not self.consumed and plugin.alive and plugin.download_token is self.token:
            self.consumed = True
            plugin.pending_update = None
            plugin.update_core(self.data)


def version_key(value):
    try:
        parts = tuple(int(part) for part in str(value).split(".")[:3])
        return parts + (0,) * (3 - len(parts))
    except ValueError:
        return (0, 0, 0)


def validate_dex(data):
    if not isinstance(data, bytes) or len(data) < 112 or len(data) > MAX_CORE_BYTES:
        raise ValueError("Неверный размер DEX-ядра")
    if data[:4] != b"dex\n" or data[7] != 0 or data[4:7] not in (b"035", b"037", b"038", b"039", b"040"):
        raise ValueError("Файл .dexan должен содержать настоящий DEX")
    if struct.unpack_from("<I", data, 32)[0] != len(data) or struct.unpack_from("<I", data, 36)[0] != 112:
        raise ValueError("Повреждён заголовок DEX")
    if hashlib.sha1(data[32:]).digest() != data[12:32] or zlib.adler32(data[12:]) & 0xffffffff != struct.unpack_from("<I", data, 8)[0]:
        raise ValueError("Не совпадает контрольная сумма DEX")
    if b"Lru/surgut/repeatfold/Bridge;\x00" not in data:
        raise ValueError("Это не ядро RepeatFold")
    return data


class CoreFileOpenHook(MethodHook):
    def __init__(self, plugin):
        self.plugin = plugin

    def before_hooked_method(self, param):
        if not self.plugin.alive:
            return
        # Source-verified AndroidUtilities.openForView(File,String,String,
        # Activity,ResourcesProvider,boolean). No message/draw hooks here.
        file, name, activity = param.args[0], param.args[1], param.args[3]
        if not str(name or "").lower().endswith(".dexan"):
            return
        if file is None or not file.exists():
            return  # Let the client handle a file which is not downloaded yet.
        param.setResult(True)
        self.plugin.on_core_file(SimpleNamespace(file=file, file_name=str(name), activity=activity))


class RepeatFoldDexLoader(BasePlugin):
    def report(self, exc):
        report = "RepeatFold loader 2.2.0\n" + "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        try:
            self.set_setting("last_error", report)
            self.log(report)
            copy_to_clipboard(report)
            BulletinHelper.show_error("DEX: подробная ошибка скопирована")
        except Exception:
            pass

    def invoke(self, core, name, types=(), values=()):
        _, clazz, instance = core
        return clazz.getDeclaredMethod(name, *types).invoke(instance, *values)

    def make_core(self, data):
        validate_dex(data)
        if int(jclass("android.os.Build$VERSION").SDK_INT) < 26:
            raise RuntimeError("DEX-загрузчик требует Android 8 или новее")
        array = jarray(jbyte)([n if n < 128 else n - 256 for n in data])
        buffer = jclass("java.nio.ByteBuffer").wrap(array)
        loader = jclass("dalvik.system.InMemoryDexClassLoader")(buffer, self.context.getClassLoader())
        clazz = loader.loadClass("ru.surgut.repeatfold.Bridge")
        # A custom-loader instance must never cross the Chaquopy boundary.
        # Static Bridge methods keep Core entirely inside the DEX loader.
        core = (loader, clazz, None)
        if int(self.invoke(core, "api")) != 2:
            raise RuntimeError("Несовместимый API ядра")
        if not clazz.getClassLoader().equals(loader):
            raise RuntimeError("DEX-класс загружен из чужого загрузчика")
        actual_version = str(self.invoke(core, "version"))
        if version_key(actual_version) < (2, 3, 4):
            raise RuntimeError("Скачано старое ядро " + actual_version +
                               "; требуется 2.3.4 или новее. SHA256: " + hashlib.sha256(data).hexdigest())
        return core

    def configure_core(self, core):
        Boolean, Integer = jclass("java.lang.Boolean"), jclass("java.lang.Integer")
        index = lambda key: max(0, min(3, int(self.get_setting(key, 1))))
        self.invoke(core, "migrateSettings", (jclass("android.content.Context").getClass(), Boolean.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE),
                    (self.context, Boolean(bool(self.get_setting("rapid", True))),
                     Integer(jint((3, 5, 7, 10)[index("threshold")])),
                     Integer(jint((2, 3, 5, 10)[index("window")])),
                     Integer(jint((1, 2, 3, 5)[index("pause")]))))

    def start_core(self, core):
        self.update_check_action = UpdateCheckAction(self)
        self.invoke(core, "setUpdateChecker", (jclass("java.lang.Runnable").getClass(),), (self.update_check_action,))
        self.configure_core(core)
        self.invoke(core, "start", (jclass("android.content.Context").getClass(),), (self.context,))

    def write_core(self, data):
        path = self.core_path + ".tmp"
        with open(path, "wb") as file:
            file.write(data)
            file.flush()
            os.fsync(file.fileno())
        os.replace(path, self.core_path)
        self.active_digest = hashlib.sha256(data).digest()

    def on_plugin_load(self):
        self.alive = True
        self.download_token = object()
        self.downloading = False
        self.active_digest = None
        self.pending_update = None
        self.offered_digest = None
        self.update_action = None
        self.core = None
        self.dialogs = []
        self.context = jclass("org.telegram.messenger.ApplicationLoader").applicationContext
        folder = os.path.join(str(get_plugins_dir()), "repeat_fold_dex_data")
        os.makedirs(folder, exist_ok=True)
        self.core_path = os.path.join(folder, "core.dexan")
        self.file_open_hook = None
        try:
            cls = jclass("org.telegram.messenger.AndroidUtilities").getClass()
            for method in cls.getDeclaredMethods():
                if str(method.getName()) != "openForView":
                    continue
                types = [str(t.getName()) for t in method.getParameterTypes()]
                if types == ["java.io.File", "java.lang.String", "java.lang.String",
                             "android.app.Activity", "org.telegram.ui.ActionBar.Theme$ResourcesProvider", "boolean"]:
                    self.file_open_hook = self.hook_method(method, CoreFileOpenHook(self))
                    break
            if self.file_open_hook is None:
                raise RuntimeError("Не найден перехват открытия файлов в этой версии exteraGram")
        except Exception as exc:
            self.report(exc)
        self.file_secret = None
        previous_secret = self.get_setting("dexan_secret", "")
        if previous_secret:
            try:
                FilesController.unregister("dexan", previous_secret)
            except (FilesController.ExtensionNotRegistered, FilesController.SecretInvalid):
                pass
        try:
            self.file_secret = FilesController.register(FilesController.FileInfo(ext="dexan", on_click=self.on_core_file))
            self.set_setting("dexan_secret", self.file_secret)
        except FilesController.ExtensionAlreadyRegistered:
            # Never remove another plugin's handler without our own secret.
            # A pre-2.0.3 loader didn't preserve its token: a process restart
            # clears that legacy registration. Native core still starts.
            self.log("Расширение dexan занято; используется перехват открытия файлов")
        def activate():
            if not self.alive:
                return
            try:
                default = validate_dex(zlib.decompress(base64.b64decode(EMBEDDED_CORE)))
                data = default
                if os.path.isfile(self.core_path):
                    try:
                        with open(self.core_path, "rb") as file:
                            data = validate_dex(file.read(MAX_CORE_BYTES + 1))
                    except Exception as exc:
                        self.report(exc)
                        data = default
                try:
                    new = self.make_core(data)
                except Exception:
                    if data == default:
                        raise
                    new = self.make_core(default)
                    data = default
                    BulletinHelper.show_info("Установлено исправленное встроенное ядро")
                try:
                    self.start_core(new)
                except Exception:
                    self.invoke(new, "stop")
                    if data == default:
                        raise
                    new = self.make_core(default)
                    self.start_core(new)
                    data = default
                    BulletinHelper.show_info("Восстановлено встроенное ядро")
                self.core = new
                self.write_core(data)
                self.download_core()
            except Exception as exc:
                self.report(exc)
        run_on_ui_thread(activate)

    def fetch_remote_core(self):
        headers = {"User-Agent": "RepeatFold/2.2.0", "Cache-Control": "no-cache, no-store",
                   "Pragma": "no-cache"}
        stamp = str(time.time_ns())
        # Resolve HEAD, then use an immutable commit URL: raw/main can be cached.
        url = CORE_URL + "?repeatfold=" + stamp
        try:
            ref_url = "https://api.github.com/repos/insurgut/dex/git/ref/heads/main?repeatfold=" + stamp
            with urllib.request.urlopen(urllib.request.Request(ref_url, headers=headers), timeout=15) as response:
                ref_data = response.read(65537)
                if len(ref_data) > 65536:
                    raise ValueError("Слишком большой ответ GitHub")
                sha = str(json.loads(ref_data)["object"]["sha"])
                if len(sha) != 40 or any(c not in "0123456789abcdef" for c in sha):
                    raise ValueError("Неверный SHA коммита GitHub")
                url = "https://raw.githubusercontent.com/insurgut/dex/" + sha + "/main.dexan"
        except Exception:
            # Public API can be rate-limited. Preserve direct download fallback.
            pass
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=20) as response:
            if not str(response.geturl()).startswith("https://"):
                raise ValueError("Источник ядра должен использовать HTTPS")
            length = response.headers.get("Content-Length")
            if length and int(length) > MAX_CORE_BYTES:
                raise ValueError("Слишком большой файл ядра")
            return validate_dex(response.read(MAX_CORE_BYTES + 1))

    def download_core(self, view=None):
        if not self.alive or self.downloading:
            return
        self.downloading = True
        token = self.download_token
        def current():
            return self.alive and self.download_token is token
        def worker():
            data, error = None, None
            try:
                data = self.fetch_remote_core()
            except Exception as exc:
                error = exc
            def apply():
                if not current():
                    return
                self.downloading = False
                if error is not None:
                    if view is not None:
                        self.report(error)
                    return
                if hashlib.sha256(data).digest() != self.active_digest:
                    digest = hashlib.sha256(data).digest()
                    self.pending_update = data
                    if digest != self.offered_digest or view is not None:
                        self.offer_update()
                elif view is not None:
                    BulletinHelper.show_info("Установлено актуальное ядро")
            if current():
                run_on_ui_thread(apply)
        threading.Thread(target=worker, name="RepeatFoldCoreDownload", daemon=True).start()

    def offer_update(self):
        if not self.alive or self.core is None or self.pending_update is None:
            return
        try:
            fragment = get_last_fragment()
            activity = fragment.getParentActivity() if fragment is not None else None
            if activity is None or activity.isFinishing():
                return
            self.update_action = UpdateAction(self, self.pending_update, self.download_token)
            self.invoke(self.core, "offerUpdate",
                        (jclass("android.app.Activity").getClass(), jclass("java.lang.Runnable").getClass()),
                        (activity, self.update_action))
            self.offered_digest = hashlib.sha256(self.pending_update).digest()
        except Exception as exc:
            self.report(exc)

    def on_core_file(self, args):
        try:
            path = str(args.file.getAbsolutePath())
            with open(path, "rb") as file:
                data = validate_dex(file.read(MAX_CORE_BYTES + 1))
            activity = args.activity
            if activity is None or activity.isFinishing():
                raise RuntimeError("Нет активного окна для обновления")
            def show():
                if not self.alive or activity.isFinishing():
                    return
                try:
                    dialog = AlertDialogBuilder(activity)
                    dialog.set_title("Обновление ядра антиспама")
                    dialog.set_message(str(args.file_name) + "\nРазмер: " + str(len(data) // 1024) + " КБ\n\nЗаменить DEX-ядро? Настройки сохранятся.")
                    dialog.set_positive_button("Обновить ядро", lambda builder, button: self.accept_update(builder, data))
                    dialog.set_negative_button("Отмена", lambda builder, button: builder.dismiss())
                    self.dialogs.append(dialog)
                    dialog.set_on_dismiss_listener(lambda builder: self.dialogs.remove(builder) if builder in self.dialogs else None)
                    dialog.show()
                except Exception as exc:
                    self.report(exc)
            run_on_ui_thread(show)
        except Exception as exc:
            self.report(exc)

    def accept_update(self, builder, data):
        builder.dismiss()
        self.update_core(data)

    def update_core(self, data):
        if not self.alive:
            return
        old = self.core
        new = None
        try:
            new = self.make_core(data)
            if old is not None:
                self.invoke(old, "stop")
            self.start_core(new)
            self.write_core(data)
            self.core = new
            self.header_factory = None
            self.footer_factory = None
            try:
                self.set_setting("core_ui_revision", hashlib.sha256(data).hexdigest(), reload_settings=True)
            except Exception as ui_error:
                self.report(ui_error)
            BulletinHelper.show_info("Ядро обновлено: " + str(self.invoke(new, "version")))
        except Exception as exc:
            if new is not None:
                try:
                    self.invoke(new, "stop")
                except Exception:
                    pass
            if old is not None:
                try:
                    self.start_core(old)
                    self.core = old
                except Exception as rollback:
                    self.report(rollback)
            self.report(exc)

    def copy_error(self, view=None):
        try:
            report = str(self.invoke(self.core, "lastError")) if self.core is not None else ""
            report = report or self.get_setting("last_error", "")
            if report:
                copy_to_clipboard(report)
                BulletinHelper.show_info("Ошибка скопирована")
            else:
                BulletinHelper.show_info("Ошибок пока нет")
        except Exception as exc:
            self.report(exc)

    def on_plugin_unload(self):
        self.alive = False
        self.download_token = None
        secret = getattr(self, "file_secret", None)
        if secret:
            try:
                FilesController.unregister("dexan", secret)
                self.set_setting("dexan_secret", "")
            except (FilesController.ExtensionNotRegistered, FilesController.SecretInvalid):
                pass
            self.file_secret = None
        core, self.core = self.core, None
        dialogs, self.dialogs = self.dialogs, []
        def stop():
            if core is not None:
                try:
                    self.invoke(core, "stop")
                except Exception as exc:
                    self.report(exc)
            for dialog in dialogs:
                try:
                    dialog.dismiss()
                except Exception:
                    pass
        run_on_ui_thread(stop)

    def show_chat_settings(self, view=None):
        def show():
            if not self.alive or self.core is None:
                return
            try:
                fragment = get_last_fragment()
                activity = fragment.getParentActivity() if fragment is not None else None
                if activity is None or activity.isFinishing():
                    raise RuntimeError("Нет активного окна для выбора чатов")
                self.invoke(self.core, "showChats", (jclass("android.app.Activity").getClass(),), (activity,))
            except Exception as exc:
                self.report(exc)
        run_on_ui_thread(show)

    def header_view(self, context, list_view, current_account, class_guid, resources_provider):
        if self.pending_update is not None and hashlib.sha256(self.pending_update).digest() != self.offered_digest:
            run_on_ui_thread(self.offer_update)
        if self.core is None:
            return jclass("android.widget.LinearLayout")(context)
        return self.invoke(self.core, "settingsView",
                           (jclass("android.content.Context").getClass(), jclass("java.lang.Integer").TYPE,
                            jclass("java.lang.Object").getClass()),
                           (context, jclass("java.lang.Integer")(jint(current_account)), resources_provider))

    def footer_view(self, context, list_view, current_account, class_guid, resources_provider):
        if self.core is None:
            return jclass("android.widget.LinearLayout")(context)
        return self.invoke(self.core, "feedbackView",
                           (jclass("android.content.Context").getClass(), jclass("java.lang.Integer").TYPE, jclass("java.lang.Object").getClass()),
                           (context, jclass("java.lang.Integer")(jint(current_account)), resources_provider))

    def create_settings(self):
        if getattr(self, "header_factory", None) is None:
            self.header_factory = SimpleSettingFactory(
                self.header_view, lambda view, item, divider, adapter, list_view: None,
                is_clickable=False, is_shadow=True)
        if getattr(self, "footer_factory", None) is None:
            self.footer_factory = SimpleSettingFactory(self.footer_view, lambda *args: None, is_clickable=False, is_shadow=False)
        return [
            Custom(factory=self.header_factory.instance.java),
            Divider(),
            Text(text="Обновить ядро сейчас", subtext="Проверить доступность обновления", on_click=self.download_core),
            Text(text="Скопировать последнюю ошибку", on_click=self.copy_error),
            Custom(factory=self.footer_factory.instance.java),
        ]
