import ru.surgut.repeatfold.Grouping;
import java.util.Arrays;
public class TestGrouping {
 static void check(int[] got,int...want){if(!Arrays.equals(got,want))throw new AssertionError(Arrays.toString(got));}
 public static void main(String[] args){
  check(Grouping.counts(new String[]{"a","a",null,"b"},new String[]{"x","x",null,"x"},new int[]{4,3,2,1},true,5,3,2),2,-1,1,1);
  check(Grouping.counts(new String[]{"a","b","c","d","e"},new String[]{"x","x","x","x","x"},new int[]{3,3,2,1,0},true,5,3,2),5,-1,-1,-1,-1);
  check(Grouping.counts(new String[]{"a","b","c","d","e"},new String[]{"x","y","x","x","x"},new int[]{3,3,2,1,0},true,5,3,2),1,1,1,1,1);
  check(Grouping.counts(new String[]{"a","b","c","d","e"},new String[]{"x","x","x","x","x"},new int[]{15,12,9,6,3},true,5,3,2),1,1,1,1,1);
  String[] exact=new String[10000],actor=new String[10000];int[] dates=new int[10000];Arrays.fill(exact,"same");Arrays.fill(actor,"user");
  for(int j=0;j<100;j++){int[] out=Grouping.counts(exact,actor,dates,true,5,3,2);if(out[0]!=10000||out[9999]!=-1)throw new AssertionError();}
  System.out.println("PASS native Java: duplicates, bursts, sender boundaries, pauses, 100x10000 stress");
 }
}
