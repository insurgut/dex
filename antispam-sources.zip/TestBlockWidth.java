import ru.surgut.repeatfold.BlockWidth;
public class TestBlockWidth {
 public static void main(String[] args){
  BlockWidth b=new BlockWidth();if(!b.observe(400,100)||!b.observe(400,240)||b.value(400)!=240||b.observe(400,180))throw new AssertionError("widest row");
  if(!b.observe(800,130)||b.value(800)!=130||b.value(400)!=0)throw new AssertionError("rotation reset");
  if(b.observe(0,100)||b.observe(800,0)||b.value(800)!=130)throw new AssertionError("unmeasured rows");
  BlockWidth edited=new BlockWidth();edited.observe(800,120);edited.observe(800,100);if(edited.value(800)!=120)throw new AssertionError("shrinking after widest deleted");
  for(int i=0;i<1000000;i++)b.observe(800,120);if(b.value(800)!=130)throw new AssertionError("stable cache");
  System.out.println("PASS widest width, rotation, deleted widest, unmeasured cells, 1000000 cached measurements");
 }
}
