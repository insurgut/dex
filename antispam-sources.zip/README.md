# RepeatFold DEX 2.0.3

All message binding, grouping, native drawing, alpha control, touch and update hooks run in Java inside `ru.surgut.repeatfold.Core`. Python is a bootstrap, settings and `.dexan` file handler only.

Deliverables:
- `repeat_fold_dex_loader.plugin`: install/enable in exteraGram; embeds the initial core.
- `RepeatFold-2.0.3.dexan`: genuine raw DEX, renamed for the custom file handler.
- Tap a `.dexan` attachment inside exteraGram after enabling the loader. The dialog contains `Обновить ядро`. The update preserves settings, validates DEX header/checksums/API and rolls back after an activation failure.

Android 8+ is required by InMemoryDexClassLoader. Installation/opening from unrelated Android file managers is not registered: the extension handler belongs to exteraGram.

Build environment used: Java 17 runtime, ECJ 3.33.0 targeting Java 8, Android framework API 16 compile-only jar, D8 8.3.37 targeting Android API 26. Telegram/Xposed APIs are resolved from the installed app. Compile-only Xposed stubs are **not** included in the DEX. Their signatures were checked against LSPosed's published source. No Telegram APK, third-party plugin binary, networking code or credentials are bundled.

Static Bridge API 2 (no DEX instances cross the Python boundary): `api()`, `version()`, `configure(boolean,int,int,int)`, `start(Context)`, `stop()`, `lastError()`. Entry class: `ru.surgut.repeatfold.Bridge`. Namespace: `ru.surgut.repeatfold`.

Validation completed: Java compilation, JVM tests of the exact grouping implementation, 100 repetitions of a 10,000-message test, D8 compilation, DEX checksum/class/reference inspection, and loader syntax/SDK validation. **Android/exteraGram execution has not been tested**. Java reflection depends on private Telegram members, so device compatibility still needs testing.

Dependency sources:
- https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.33.0/ecj-3.33.0.jar
- https://repo.maven.apache.org/maven2/com/google/android/android/4.1.1.4/android-4.1.1.4.jar
- https://storage.googleapis.com/r8-releases/raw/8.3.37/r8.jar
- https://github.com/LSPosed/LSPosed/tree/master/core/src/main/java/de/robv/android/xposed

Loader 2.0.2: explicitly preserves and releases its FilesController registration token. A legacy 2.0.0/2.0.1 file handler may require one complete app process restart because that loader did not preserve its token. Conflicts no longer abort native-core startup. Native core remains 2.0.1.

Version 2.0.3: native adapter binding always runs, even for invisible duplicates. Telegram requires a populated MessageObject in onViewAttachedToWindow. Hiding occurs after native binding, while invisible-row measurement remains skipped. The loader rejects cores older than 2.0.3 and automatically replaces saved older cores with the embedded fixed core.

Version 2.1.0: native lazy chat picker via BottomSheet, pinned dialogs first, avatars and username. All chats enabled by default. Exclusions persist in account-scoped SharedPreferences and are checked by cached adapter identity, with no Python calls during binding. Bridge.showChats(Activity) opens the picker. Loader requires core >=2.1.0 so automatic downloads cannot remove chat exclusion support.

Version 2.1.0: native lazy chat picker via BottomSheet, pinned dialogs first, avatars and username. All chats enabled by default. Exclusions persist in account-scoped SharedPreferences and are checked by cached adapter identity, with no Python calls during binding. Bridge.showChats(Activity) opens the picker. Loader requires core >=2.1.0 so automatic downloads cannot remove chat exclusion support.

2.1.1: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.1: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.2: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.3: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.4: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.6: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.6: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.1.7: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.0: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.0: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.1: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.1: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.1: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.2: ListView owns its vertical gesture, sheet swipe dismissal and nested scrolling disabled. List shares bounded height with header. Close via Back or outside tap.

2.2.2: Grouped rounded settings adapt to visible controls. Badge count and touch survive optional emoji failures; Canvas isolated. Native update bulletin with premium emoji and Update button; loader announces downloaded updates before applying.


## Проверка памяти при каждом изменении ядра

Сборка обязательно запускает TestRetention2311 на реальных классах Core.State и Core.Snapshot: кэш не должен удерживать адаптер, ячейку и список сообщений. Геометрия капсулы и группировка также проверяются автоматически. Это JVM-регрессии, а не замена heap-профилированию Android. Проверять очистку callbacks, хуков, окон, bitmap и подписок AnimatedEmojiDrawable при unload/update.
