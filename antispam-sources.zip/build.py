"""Rebuild actual native DEX; runtime needs a Java executable and network for dependencies."""
import base64
import pathlib
import subprocess
import urllib.request
import zipfile
import zlib

ROOT = pathlib.Path(__file__).resolve().parent
TOOLS = ROOT / 'tools'
TOOLS.mkdir(exist_ok=True)
urls = {
    'ecj.jar': 'https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.33.0/ecj-3.33.0.jar',
    'android.jar': 'https://repo.maven.apache.org/maven2/com/google/android/android/4.1.1.4/android-4.1.1.4.jar',
    'r8.jar': 'https://storage.googleapis.com/r8-releases/raw/8.3.37/r8.jar',
}
for filename, url in urls.items():
    path = TOOLS / filename
    if not path.exists():
        with urllib.request.urlopen(url, timeout=60) as response:
            path.write_bytes(response.read())
version = __import__('json').loads((ROOT/'manifest.json').read_text())['version']
classes = ROOT / ('classes'+version.replace('.', ''))
sources = [str(p) for folder in ('stubs', 'src') for p in (ROOT / folder).rglob('*.java')]
subprocess.run(['java', '-jar', str(TOOLS/'ecj.jar'), '-8', '-encoding', 'UTF-8', '-classpath', str(TOOLS/'android.jar'), '-d', str(classes), *sources], check=True)
# Every core build runs geometry, grouping and cache-retention regressions.
tests = ROOT / ('test'+version.replace('.', ''))
classpath = str(classes)+':'+str(TOOLS/'android.jar')
subprocess.run(['java','-jar',str(TOOLS/'ecj.jar'),'-8','-nowarn','-classpath',classpath,'-d',str(tests),*[str(p) for p in ROOT.glob('Test*.java')]],check=True)
for test in ['TestGrouping','TestLongBlocks','TestBlockWidth','ru.surgut.repeatfold.TestBadge2311','TestRetention2311']:
    subprocess.run(['java','-cp',classpath+':'+str(tests),test],check=True)
for name, folder in [('core-classes.jar', 'ru'), ('xposed-stubs.jar', 'de')]:
    with zipfile.ZipFile(ROOT/name, 'w') as archive:
        for path in (classes/folder).rglob('*.class'):
            archive.write(path, str(path.relative_to(classes)))
dex = ROOT/'dex'
dex.mkdir(exist_ok=True)
subprocess.run(['java', '-cp', str(TOOLS/'r8.jar'), 'com.android.tools.r8.D8', '--min-api', '26', '--lib', str(TOOLS/'android.jar'), '--classpath', str(ROOT/'xposed-stubs.jar'), '--output', str(dex), str(ROOT/'core-classes.jar')], check=True)
data = (dex/'classes.dex').read_bytes()
(ROOT/('RepeatFold-'+version+'.dexan')).write_bytes(data)
loader = (ROOT/'loader_template.py').read_text().replace('@@CORE@@', base64.b64encode(zlib.compress(data, 9)).decode())
(ROOT/'repeat_fold_dex_loader.plugin').write_text(loader)
print('Built genuine DEX core and bootstrap loader')
