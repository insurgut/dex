package ru.surgut.repeatfold;
public class TestBadge2311 {
 public static void main(String[] args){
  for(int width=120;width<=900;width+=20)for(int l=2;l<width-20;l+=7)for(int r=l+20;r<=width-2;r+=13)for(boolean out:new boolean[]{true,false}){
   boolean fitsLeft=l-4-56>=2,fitsRight=r+4+56<=width-2;
   boolean below=BadgePlacement.below(width,l,r,out,28,4,2);
   if(below==(fitsLeft||fitsRight))throw new AssertionError("side selection");
   float x=BadgePlacement.x(width,l,r,out,below,28,4,2);
   if(x-28<2||x+28>width-2)throw new AssertionError("clipping");
   if(!below&&!(x+28<=l-4||x-28>=r+4))throw new AssertionError("bubble overlap");
  }
  if(BadgePlacement.below(400,190,390,true,28,4,2))throw new AssertionError("outgoing fits left");
  if(BadgePlacement.below(400,5,200,false,28,4,2))throw new AssertionError("incoming fits right");
  System.out.println("PASS capsule placement: preferred and alternate side, both blocked, no clipping or overlap");
 }
}
