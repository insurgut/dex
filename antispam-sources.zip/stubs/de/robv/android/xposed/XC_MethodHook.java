package de.robv.android.xposed;
public abstract class XC_MethodHook {
 public XC_MethodHook(){}
 protected void beforeHookedMethod(MethodHookParam p) throws Throwable{}
 protected void afterHookedMethod(MethodHookParam p) throws Throwable{}
 public static class MethodHookParam { public Object thisObject; public Object[] args; public void setResult(Object o){} public Object getResult(){return null;} }
 public class Unhook { public void unhook(){} }
}
